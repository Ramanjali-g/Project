package com.careertrack.controller;

import com.careertrack.dto.EmailExtractRequest;
import com.careertrack.model.EmailEvent;
import com.careertrack.model.JobApplication;
import com.careertrack.security.CurrentUser;
import com.careertrack.service.EmailEventService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * AI Email Assistant (FR-12, FR-13, FR-14, section 7).
 *
 * NOTE on scope: this MVP does not implement live Gmail/Outlook OAuth message
 * fetching - the user pastes/forwards the relevant email text explicitly,
 * which satisfies the "explicit authorization" and "minimize email
 * processing" requirements (FR-24, section 7.5) trivially, since no inbox
 * access happens at all. To extend this into a live integration:
 *   1. Add Gmail API / Microsoft Graph OAuth2 client registration.
 *   2. After the user authorizes, fetch only career-relevant messages
 *      (e.g. via Gmail search query filters) instead of the full inbox.
 *   3. Call EmailEventService#extractAndStore for each message body instead
 *      of taking emailText from the request.
 */
@RestController
@RequestMapping("/api/email-events")
@RequiredArgsConstructor
public class EmailEventController {

    private final EmailEventService emailEventService;

    @GetMapping
    public List<EmailEvent> list() {
        return emailEventService.listForUser(CurrentUser.id());
    }

    @PostMapping("/extract")
    public ResponseEntity<EmailEvent> extract(@Valid @RequestBody EmailExtractRequest request) {
        EmailEvent event = emailEventService.extractAndStore(CurrentUser.id(), request.getEmailText(), request.getSourceMessageRef());
        return ResponseEntity.ok(event);
    }

    @PostMapping("/{id}/confirm")
    public JobApplication confirm(@PathVariable String id, @RequestBody Map<String, String> body) {
        String applicationId = body.get("applicationId");
        return emailEventService.confirmAndApply(id, applicationId, CurrentUser.id());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> dismiss(@PathVariable String id) {
        emailEventService.dismiss(id, CurrentUser.id());
        return ResponseEntity.noContent().build();
    }
}
