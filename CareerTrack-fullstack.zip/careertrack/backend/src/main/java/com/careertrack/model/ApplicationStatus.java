package com.careertrack.model;

public enum ApplicationStatus {
    INTERESTED,
    APPLIED,
    ASSESSMENT,
    SHORTLISTED,
    INTERVIEW,
    OFFER,
    SELECTED,
    REJECTED,
    WITHDRAWN
}
