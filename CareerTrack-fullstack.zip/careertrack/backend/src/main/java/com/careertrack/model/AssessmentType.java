package com.careertrack.model;

public enum AssessmentType {
    CODING_TEST,
    ONLINE_ASSESSMENT,
    ASSIGNMENT,
    APTITUDE_TEST,
    OTHER
}
