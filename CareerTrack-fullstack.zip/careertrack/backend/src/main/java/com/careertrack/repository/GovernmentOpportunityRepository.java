package com.careertrack.repository;

import com.careertrack.model.GovernmentOpportunity;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;

public interface GovernmentOpportunityRepository extends MongoRepository<GovernmentOpportunity, String> {
    List<GovernmentOpportunity> findByUserId(String userId);
    Optional<GovernmentOpportunity> findByIdAndUserId(String id, String userId);
}
