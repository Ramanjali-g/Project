package com.careertrack.service;

import com.careertrack.exception.ResourceNotFoundException;
import com.careertrack.model.Company;
import com.careertrack.repository.CompanyRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CompanyService {

    private final CompanyRepository companyRepository;

    public List<Company> listForUser(String userId) {
        return companyRepository.findByUserId(userId);
    }

    public Company get(String id, String userId) {
        return companyRepository.findByIdAndUserId(id, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Company not found"));
    }

    public Company create(Company company, String userId) {
        company.setId(null);
        company.setUserId(userId);
        return companyRepository.save(company);
    }

    public Company update(String id, Company updates, String userId) {
        Company existing = get(id, userId);
        existing.setName(updates.getName());
        existing.setWebsite(updates.getWebsite());
        existing.setIndustry(updates.getIndustry());
        existing.setLocation(updates.getLocation());
        existing.setNotes(updates.getNotes());
        return companyRepository.save(existing);
    }

    public void delete(String id, String userId) {
        Company existing = get(id, userId);
        companyRepository.delete(existing);
    }
}
