package com.careertrack.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/** A single unified-calendar entry (FR-18), normalized from several source collections. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CalendarEvent {
    private String id;
    private String type; // INTERVIEW | ASSESSMENT | GOVERNMENT_DEADLINE | EXAM | EXAM_REGISTRATION
    private String title;
    private LocalDateTime dateTime;
    private String relatedEntityId;
}
