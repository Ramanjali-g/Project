package com.careertrack.service;

import com.careertrack.exception.ResourceNotFoundException;
import com.careertrack.model.StudyProgress;
import com.careertrack.repository.StudyProgressRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class StudyProgressService {

    private final StudyProgressRepository repository;

    public List<StudyProgress> listForUser(String userId) {
        return repository.findByUserId(userId);
    }

    public StudyProgress get(String id, String userId) {
        return repository.findByIdAndUserId(id, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Study progress entry not found"));
    }

    public StudyProgress create(StudyProgress item, String userId) {
        item.setId(null);
        item.setUserId(userId);
        return repository.save(item);
    }

    public StudyProgress update(String id, StudyProgress updates, String userId) {
        StudyProgress existing = get(id, userId);
        existing.setExamName(updates.getExamName());
        existing.setSubject(updates.getSubject());
        existing.setTopic(updates.getTopic());
        existing.setProgressPercent(updates.getProgressPercent());
        existing.setMockTestsTaken(updates.getMockTestsTaken());
        existing.setTargetScore(updates.getTargetScore());
        existing.setActualScore(updates.getActualScore());
        existing.setNotes(updates.getNotes());
        return repository.save(existing);
    }

    public void delete(String id, String userId) {
        repository.delete(get(id, userId));
    }
}
