package com.careertrack.service;

import com.careertrack.exception.ResourceNotFoundException;
import com.careertrack.model.ApplicationStatus;
import com.careertrack.model.Company;
import com.careertrack.model.JobApplication;
import com.careertrack.repository.CompanyRepository;
import com.careertrack.repository.JobApplicationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class JobApplicationService {

    private final JobApplicationRepository applicationRepository;
    private final CompanyRepository companyRepository;
    private final NotificationService notificationService;

    public List<JobApplication> listForUser(String userId, ApplicationStatus status) {
        if (status != null) {
            return applicationRepository.findByUserIdAndStatus(userId, status);
        }
        return applicationRepository.findByUserId(userId);
    }

    public JobApplication get(String id, String userId) {
        return applicationRepository.findByIdAndUserId(id, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Application not found"));
    }

    public JobApplication create(JobApplication application, String userId) {
        application.setId(null);
        application.setUserId(userId);
        denormalizeCompanyName(application, userId);
        if (application.getStatus() == null) {
            application.setStatus(ApplicationStatus.INTERESTED);
        }
        return applicationRepository.save(application);
    }

    public JobApplication update(String id, JobApplication updates, String userId) {
        JobApplication existing = get(id, userId);
        ApplicationStatus previousStatus = existing.getStatus();

        existing.setCompanyId(updates.getCompanyId());
        existing.setRole(updates.getRole());
        existing.setType(updates.getType());
        existing.setStatus(updates.getStatus());
        existing.setLocation(updates.getLocation());
        existing.setSalary(updates.getSalary());
        existing.setJobUrl(updates.getJobUrl());
        existing.setNotes(updates.getNotes());
        existing.setAppliedDate(updates.getAppliedDate());
        denormalizeCompanyName(existing, userId);

        JobApplication saved = applicationRepository.save(existing);

        if (previousStatus != saved.getStatus()) {
            notificationService.notifyStatusChange(userId, saved);
        }
        return saved;
    }

    public void delete(String id, String userId) {
        JobApplication existing = get(id, userId);
        applicationRepository.delete(existing);
    }

    public Map<ApplicationStatus, Long> countsByStatus(String userId) {
        return java.util.Arrays.stream(ApplicationStatus.values())
                .collect(java.util.stream.Collectors.toMap(
                        s -> s,
                        s -> applicationRepository.countByUserIdAndStatus(userId, s)
                ));
    }

    private void denormalizeCompanyName(JobApplication application, String userId) {
        if (application.getCompanyId() != null) {
            companyRepository.findByIdAndUserId(application.getCompanyId(), userId)
                    .map(Company::getName)
                    .ifPresent(application::setCompanyName);
        }
    }
}
