package com.careertrack.model;

public enum OpportunityCategory {
    JOB,
    INTERNSHIP,
    GOVERNMENT,
    EXAM
}
