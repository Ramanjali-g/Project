package com.careertrack.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "studyProgress")
public class StudyProgress {

    @Id
    private String id;

    @Indexed
    private String userId;

    /** Free text link, e.g. "GATE" or a competitiveExamId. */
    private String examName;
    private String subject;
    private String topic;

    /** 0-100 */
    private Integer progressPercent;

    private Integer mockTestsTaken;
    private Double targetScore;
    private Double actualScore;
    private String notes;

    @CreatedDate
    private Instant createdAt;
}
