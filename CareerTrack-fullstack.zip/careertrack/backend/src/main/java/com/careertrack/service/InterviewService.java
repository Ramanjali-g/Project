package com.careertrack.service;

import com.careertrack.exception.ResourceNotFoundException;
import com.careertrack.model.Interview;
import com.careertrack.model.NotificationType;
import com.careertrack.repository.InterviewRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class InterviewService {

    private final InterviewRepository interviewRepository;
    private final NotificationService notificationService;

    public List<Interview> listForUser(String userId) {
        return interviewRepository.findByUserId(userId);
    }

    public List<Interview> upcoming(String userId, int days) {
        LocalDateTime now = LocalDateTime.now();
        return interviewRepository.findByUserIdAndDateTimeBetween(userId, now, now.plusDays(days));
    }

    public Interview get(String id, String userId) {
        return interviewRepository.findByIdAndUserId(id, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Interview not found"));
    }

    public Interview create(Interview interview, String userId) {
        interview.setId(null);
        interview.setUserId(userId);
        if (interview.getStatus() == null) {
            interview.setStatus(com.careertrack.model.InterviewStatus.SCHEDULED);
        }
        Interview saved = interviewRepository.save(interview);
        notificationService.create(
                userId,
                "Interview scheduled",
                saved.getRole() + " interview at " + saved.getCompany() + " scheduled for " + saved.getDateTime(),
                NotificationType.INTERVIEW,
                saved.getId()
        );
        return saved;
    }

    public Interview update(String id, Interview updates, String userId) {
        Interview existing = get(id, userId);
        existing.setApplicationId(updates.getApplicationId());
        existing.setCompany(updates.getCompany());
        existing.setRole(updates.getRole());
        existing.setType(updates.getType());
        existing.setRound(updates.getRound());
        existing.setDateTime(updates.getDateTime());
        existing.setStatus(updates.getStatus());
        existing.setNotes(updates.getNotes());
        return interviewRepository.save(existing);
    }

    public void delete(String id, String userId) {
        interviewRepository.delete(get(id, userId));
    }
}
