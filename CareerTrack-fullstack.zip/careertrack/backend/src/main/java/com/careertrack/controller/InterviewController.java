package com.careertrack.controller;

import com.careertrack.model.Interview;
import com.careertrack.security.CurrentUser;
import com.careertrack.service.InterviewService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/interviews")
@RequiredArgsConstructor
public class InterviewController {

    private final InterviewService interviewService;

    @GetMapping
    public List<Interview> list() {
        return interviewService.listForUser(CurrentUser.id());
    }

    @GetMapping("/{id}")
    public Interview get(@PathVariable String id) {
        return interviewService.get(id, CurrentUser.id());
    }

    @PostMapping
    public ResponseEntity<Interview> create(@RequestBody Interview interview) {
        return ResponseEntity.ok(interviewService.create(interview, CurrentUser.id()));
    }

    @PutMapping("/{id}")
    public Interview update(@PathVariable String id, @RequestBody Interview interview) {
        return interviewService.update(id, interview, CurrentUser.id());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        interviewService.delete(id, CurrentUser.id());
        return ResponseEntity.noContent().build();
    }
}
