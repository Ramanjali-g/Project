package com.careertrack.controller;

import com.careertrack.model.GovernmentOpportunity;
import com.careertrack.security.CurrentUser;
import com.careertrack.service.GovernmentOpportunityService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/government-opportunities")
@RequiredArgsConstructor
public class GovernmentOpportunityController {

    private final GovernmentOpportunityService service;

    @GetMapping
    public List<GovernmentOpportunity> list() {
        return service.listForUser(CurrentUser.id());
    }

    @GetMapping("/{id}")
    public GovernmentOpportunity get(@PathVariable String id) {
        return service.get(id, CurrentUser.id());
    }

    @PostMapping
    public ResponseEntity<GovernmentOpportunity> create(@RequestBody GovernmentOpportunity item) {
        return ResponseEntity.ok(service.create(item, CurrentUser.id()));
    }

    @PutMapping("/{id}")
    public GovernmentOpportunity update(@PathVariable String id, @RequestBody GovernmentOpportunity item) {
        return service.update(id, item, CurrentUser.id());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        service.delete(id, CurrentUser.id());
        return ResponseEntity.noContent().build();
    }
}
