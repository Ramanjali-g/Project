package com.careertrack.repository;

import com.careertrack.model.EmailEvent;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;

public interface EmailEventRepository extends MongoRepository<EmailEvent, String> {
    List<EmailEvent> findByUserIdOrderByCreatedAtDesc(String userId);
    Optional<EmailEvent> findByIdAndUserId(String id, String userId);
}
