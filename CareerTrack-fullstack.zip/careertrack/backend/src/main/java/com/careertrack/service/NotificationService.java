package com.careertrack.service;

import com.careertrack.exception.ResourceNotFoundException;
import com.careertrack.model.JobApplication;
import com.careertrack.model.Notification;
import com.careertrack.model.NotificationType;
import com.careertrack.repository.NotificationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;

@Service
@RequiredArgsConstructor
public class NotificationService {

    private final NotificationRepository notificationRepository;

    public List<Notification> listForUser(String userId, boolean unreadOnly) {
        if (unreadOnly) {
            return notificationRepository.findByUserIdAndIsReadFalseOrderByCreatedAtDesc(userId);
        }
        return notificationRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }

    public long unreadCount(String userId) {
        return notificationRepository.countByUserIdAndIsReadFalse(userId);
    }

    public Notification markRead(String id, String userId) {
        Notification notification = notificationRepository.findByIdAndUserId(id, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found"));
        notification.setRead(true);
        return notificationRepository.save(notification);
    }

    public void markAllRead(String userId) {
        List<Notification> unread = notificationRepository.findByUserIdAndIsReadFalseOrderByCreatedAtDesc(userId);
        unread.forEach(n -> n.setRead(true));
        notificationRepository.saveAll(unread);
    }

    public void delete(String id, String userId) {
        Notification notification = notificationRepository.findByIdAndUserId(id, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found"));
        notificationRepository.delete(notification);
    }

    public Notification create(String userId, String title, String message, NotificationType type, String relatedEntityId) {
        Notification notification = Notification.builder()
                .userId(userId)
                .title(title)
                .message(message)
                .type(type)
                .relatedEntityId(relatedEntityId)
                .isRead(false)
                .scheduledFor(Instant.now())
                .build();
        return notificationRepository.save(notification);
    }

    /** Creates a reminder notification unless one already exists for this entity+type (used by the daily reminder scheduler). */
    public void createIfAbsent(String userId, String title, String message, NotificationType type, String relatedEntityId) {
        boolean exists = notificationRepository.existsByUserIdAndRelatedEntityIdAndType(userId, relatedEntityId, type);
        if (!exists) {
            create(userId, title, message, type, relatedEntityId);
        }
    }

    public void notifyStatusChange(String userId, JobApplication application) {
        String company = application.getCompanyName() != null ? application.getCompanyName() : "the company";
        create(
                userId,
                "Application status updated",
                "Your application for " + application.getRole() + " at " + company + " is now " + application.getStatus() + ".",
                NotificationType.GENERAL,
                application.getId()
        );
    }
}
