package com.careertrack.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class EmailExtractRequest {
    @NotBlank(message = "Email text is required")
    private String emailText;

    /** Optional free-text reference, e.g. Gmail message id, for audit purposes only. */
    private String sourceMessageRef;
}
