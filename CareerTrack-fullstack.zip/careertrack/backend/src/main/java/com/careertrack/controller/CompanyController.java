package com.careertrack.controller;

import com.careertrack.model.Company;
import com.careertrack.security.CurrentUser;
import com.careertrack.service.CompanyService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/companies")
@RequiredArgsConstructor
public class CompanyController {

    private final CompanyService companyService;

    @GetMapping
    public List<Company> list() {
        return companyService.listForUser(CurrentUser.id());
    }

    @GetMapping("/{id}")
    public Company get(@PathVariable String id) {
        return companyService.get(id, CurrentUser.id());
    }

    @PostMapping
    public ResponseEntity<Company> create(@RequestBody Company company) {
        return ResponseEntity.ok(companyService.create(company, CurrentUser.id()));
    }

    @PutMapping("/{id}")
    public Company update(@PathVariable String id, @RequestBody Company company) {
        return companyService.update(id, company, CurrentUser.id());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        companyService.delete(id, CurrentUser.id());
        return ResponseEntity.noContent().build();
    }
}
