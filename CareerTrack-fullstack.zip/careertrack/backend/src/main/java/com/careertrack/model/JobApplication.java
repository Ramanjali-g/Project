package com.careertrack.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "jobApplications")
public class JobApplication {

    @Id
    private String id;

    @Indexed
    private String userId;

    private String companyId;
    /** Denormalized company name for fast list rendering without a join. */
    private String companyName;

    private String role;
    private ApplicationType type;
    private ApplicationStatus status;

    private String location;
    private Double salary;
    private String jobUrl;
    private String notes;

    private LocalDate appliedDate;

    @CreatedDate
    private Instant createdAt;

    @LastModifiedDate
    private Instant updatedAt;
}
