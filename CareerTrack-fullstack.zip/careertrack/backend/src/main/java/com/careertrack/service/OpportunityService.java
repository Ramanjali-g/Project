package com.careertrack.service;

import com.careertrack.exception.ResourceNotFoundException;
import com.careertrack.model.Opportunity;
import com.careertrack.model.OpportunityCategory;
import com.careertrack.model.User;
import com.careertrack.repository.OpportunityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Handles the aggregated "opportunities" collection (FR-10, FR-11, FR-15,
 * section 8) and personalized relevance scoring (FR-16).
 *
 * Records are added via POST /api/opportunities (manually curated, imported,
 * or - in a future iteration - written by a scheduled collector job; see
 * scheduler/OpportunityCollectorScheduler.java). This service does not
 * scrape any external site itself.
 */
@Service
@RequiredArgsConstructor
public class OpportunityService {

    private final OpportunityRepository opportunityRepository;
    private final UserService userService;

    public List<Opportunity> search(OpportunityCategory category, String role, String location) {
        List<Opportunity> results;
        if (category != null) {
            results = opportunityRepository.findByCategory(category);
        } else {
            results = opportunityRepository.findAll();
        }
        if (role != null && !role.isBlank()) {
            String needle = role.toLowerCase(Locale.ROOT);
            results = results.stream()
                    .filter(o -> o.getRole() != null && o.getRole().toLowerCase(Locale.ROOT).contains(needle)
                            || o.getTitle() != null && o.getTitle().toLowerCase(Locale.ROOT).contains(needle))
                    .toList();
        }
        if (location != null && !location.isBlank()) {
            String needle = location.toLowerCase(Locale.ROOT);
            results = results.stream()
                    .filter(o -> o.getLocation() != null && o.getLocation().toLowerCase(Locale.ROOT).contains(needle))
                    .toList();
        }
        return results;
    }

    /** Returns opportunities sorted by a simple relevance score against the user's profile (FR-16). */
    public List<OpportunityMatch> personalizedFeed(String userId, int limit) {
        User user = userService.getById(userId);
        User.Profile profile = user.getProfile();
        List<Opportunity> all = opportunityRepository.findAll();

        return all.stream()
                .map(o -> new OpportunityMatch(o, score(o, profile), explain(o, profile)))
                .sorted(Comparator.comparingDouble(OpportunityMatch::score).reversed())
                .limit(limit)
                .toList();
    }

    private double score(Opportunity o, User.Profile profile) {
        if (profile == null) return 0;
        double score = 0;
        String haystack = String.join(" ",
                nullToEmpty(o.getTitle()), nullToEmpty(o.getRole()), nullToEmpty(o.getDescription())
        ).toLowerCase(Locale.ROOT);

        if (profile.getSkills() != null) {
            for (String skill : profile.getSkills()) {
                if (skill != null && !skill.isBlank() && haystack.contains(skill.toLowerCase(Locale.ROOT))) {
                    score += 2.0;
                }
            }
        }
        if (profile.getPreferredRoles() != null) {
            for (String role : profile.getPreferredRoles()) {
                if (role != null && !role.isBlank() && haystack.contains(role.toLowerCase(Locale.ROOT))) {
                    score += 3.0;
                }
            }
        }
        if (profile.getPreferredLocations() != null && o.getLocation() != null) {
            for (String loc : profile.getPreferredLocations()) {
                if (loc != null && o.getLocation().toLowerCase(Locale.ROOT).contains(loc.toLowerCase(Locale.ROOT))) {
                    score += 1.5;
                }
            }
        }
        if (profile.getExamInterests() != null && o.getCategory() == com.careertrack.model.OpportunityCategory.EXAM) {
            for (String exam : profile.getExamInterests()) {
                if (exam != null && haystack.contains(exam.toLowerCase(Locale.ROOT))) {
                    score += 3.0;
                }
            }
        }
        return score;
    }

    private String explain(Opportunity o, User.Profile profile) {
        if (profile == null) return "Complete your profile to get personalized matches.";
        StringBuilder sb = new StringBuilder();
        double s = score(o, profile);
        if (s == 0) {
            return "General match based on category; add skills/preferred roles to your profile for better matches.";
        }
        sb.append("Matches your profile");
        if (profile.getSkills() != null && !profile.getSkills().isEmpty()) {
            sb.append(" (skills, preferred roles/locations considered)");
        }
        sb.append(".");
        return sb.toString();
    }

    private String nullToEmpty(String s) {
        return s == null ? "" : s;
    }

    public Opportunity get(String id) {
        return opportunityRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Opportunity not found"));
    }

    public Opportunity create(Opportunity opportunity) {
        opportunity.setId(null);
        if (opportunity.getLastCheckedAt() == null) {
            opportunity.setLastCheckedAt(Instant.now());
        }
        return opportunityRepository.save(opportunity);
    }

    public Opportunity update(String id, Opportunity updates) {
        Opportunity existing = get(id);
        existing.setTitle(updates.getTitle());
        existing.setCategory(updates.getCategory());
        existing.setOrganization(updates.getOrganization());
        existing.setLocation(updates.getLocation());
        existing.setDescription(updates.getDescription());
        existing.setRole(updates.getRole());
        existing.setEligibility(updates.getEligibility());
        existing.setPublishedDate(updates.getPublishedDate());
        existing.setDeadline(updates.getDeadline());
        existing.setSourceName(updates.getSourceName());
        existing.setSourceUrl(updates.getSourceUrl());
        existing.setVerified(updates.isVerified());
        existing.setLastCheckedAt(Instant.now());
        return opportunityRepository.save(existing);
    }

    public void delete(String id) {
        opportunityRepository.delete(get(id));
    }

    public record OpportunityMatch(Opportunity opportunity, double score, String explanation) {
    }
}
