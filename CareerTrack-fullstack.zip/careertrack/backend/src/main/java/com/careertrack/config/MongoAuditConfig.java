package com.careertrack.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.config.EnableMongoAuditing;

/** Enables automatic population of @CreatedDate / @LastModifiedDate fields. */
@Configuration
@EnableMongoAuditing
public class MongoAuditConfig {
}
