package com.careertrack.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "governmentOpportunities")
public class GovernmentOpportunity {

    @Id
    private String id;

    /** Owner tracking this opportunity for themselves. */
    @Indexed
    private String userId;

    private String title;
    private String organization;
    private String eligibility;

    private LocalDate notificationDate;
    private LocalDate registrationDeadline;
    private LocalDate examDate;
    private LocalDate resultDate;

    private OpportunityStatus status;
    private String sourceUrl;
    private String sourceName;
    private String notes;

    @CreatedDate
    private Instant createdAt;
}
