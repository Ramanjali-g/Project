package com.careertrack.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "users")
public class User {

    @Id
    private String id;

    @Indexed(unique = true)
    private String email;

    /** BCrypt hash. Never returned to clients - see AuthService/UserController mapping. */
    private String password;

    private String name;

    @Builder.Default
    private List<String> roles = List.of("ROLE_USER");

    private Profile profile;

    @CreatedDate
    private Instant createdAt;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Profile {
        private String education;
        private List<String> skills;
        private String experience; // free text summary, e.g. "2 years as backend developer"
        private List<String> preferredRoles;
        private List<String> preferredLocations;
        private List<String> examInterests; // e.g. ["GATE", "CAT"]
    }
}
