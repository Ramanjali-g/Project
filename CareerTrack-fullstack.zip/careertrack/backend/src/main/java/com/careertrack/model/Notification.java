package com.careertrack.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "notifications")
public class Notification {

    @Id
    private String id;

    @Indexed
    private String userId;

    private String title;
    private String message;
    private NotificationType type;

    /** id of the related application / interview / assessment / exam, if any */
    private String relatedEntityId;

    @Builder.Default
    private boolean isRead = false;

    private Instant scheduledFor;

    @CreatedDate
    private Instant createdAt;
}
