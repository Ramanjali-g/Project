package com.careertrack.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "competitiveExams")
public class CompetitiveExam {

    @Id
    private String id;

    @Indexed
    private String userId;

    /** e.g. GATE, CAT, GRE, GMAT, CUET, JEE, NEET, OTHER */
    private String examName;

    private LocalDate registrationDeadline;
    private LocalDate admitCardDate;
    private LocalDate examDate;
    private LocalDate resultDate;

    private Double targetScore;
    private Double actualScore;

    private OpportunityStatus status;
    private String notes;

    @CreatedDate
    private Instant createdAt;
}
