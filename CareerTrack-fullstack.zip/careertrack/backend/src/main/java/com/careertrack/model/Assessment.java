package com.careertrack.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "assessments")
public class Assessment {

    @Id
    private String id;

    @Indexed
    private String userId;

    private String applicationId;

    private String company;
    private String role;
    private AssessmentType type;
    private LocalDateTime deadline;
    private AssessmentStatus status;
    private String notes;

    @CreatedDate
    private Instant createdAt;
}
