package com.careertrack.controller;

import com.careertrack.model.User;
import com.careertrack.security.CurrentUser;
import com.careertrack.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @GetMapping("/me")
    public ResponseEntity<User> me() {
        User user = userService.getById(CurrentUser.id());
        user.setPassword(null);
        return ResponseEntity.ok(user);
    }

    @PutMapping("/me")
    public ResponseEntity<User> updateMe(@RequestBody User update) {
        String userId = CurrentUser.id();
        User saved = userService.updateBasicInfo(userId, update.getName());
        if (update.getProfile() != null) {
            saved = userService.updateProfile(userId, update.getProfile());
        }
        saved.setPassword(null);
        return ResponseEntity.ok(saved);
    }
}
