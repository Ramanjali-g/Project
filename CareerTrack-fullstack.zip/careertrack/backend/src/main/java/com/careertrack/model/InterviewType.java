package com.careertrack.model;

public enum InterviewType {
    PHONE_SCREEN,
    TECHNICAL,
    HR,
    MANAGERIAL,
    ONSITE,
    VIRTUAL,
    OTHER
}
