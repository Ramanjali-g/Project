package com.careertrack.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "interviews")
public class Interview {

    @Id
    private String id;

    @Indexed
    private String userId;

    /** Optional link back to the job application this interview belongs to. */
    private String applicationId;

    private String company;
    private String role;
    private InterviewType type;
    private Integer round;
    private LocalDateTime dateTime;
    private InterviewStatus status;
    private String notes;

    @CreatedDate
    private Instant createdAt;
}
