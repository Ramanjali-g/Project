package com.careertrack.repository;

import com.careertrack.model.StudyProgress;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;

public interface StudyProgressRepository extends MongoRepository<StudyProgress, String> {
    List<StudyProgress> findByUserId(String userId);
    Optional<StudyProgress> findByIdAndUserId(String id, String userId);
}
