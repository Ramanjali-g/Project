package com.careertrack.dto;

import com.careertrack.model.ApplicationStatus;
import com.careertrack.model.Assessment;
import com.careertrack.model.CompetitiveExam;
import com.careertrack.model.GovernmentOpportunity;
import com.careertrack.model.Interview;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DashboardResponse {
    private long totalApplications;
    private Map<ApplicationStatus, Long> applicationsByStatus;

    private List<Interview> upcomingInterviews;
    private List<Assessment> upcomingAssessments;
    private List<GovernmentOpportunity> upcomingGovernmentDeadlines;
    private List<CompetitiveExam> upcomingExams;

    private long unreadNotifications;
}
