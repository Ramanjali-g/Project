package com.careertrack.controller;

import com.careertrack.model.StudyProgress;
import com.careertrack.security.CurrentUser;
import com.careertrack.service.StudyProgressService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/study-progress")
@RequiredArgsConstructor
public class StudyProgressController {

    private final StudyProgressService service;

    @GetMapping
    public List<StudyProgress> list() {
        return service.listForUser(CurrentUser.id());
    }

    @GetMapping("/{id}")
    public StudyProgress get(@PathVariable String id) {
        return service.get(id, CurrentUser.id());
    }

    @PostMapping
    public ResponseEntity<StudyProgress> create(@RequestBody StudyProgress item) {
        return ResponseEntity.ok(service.create(item, CurrentUser.id()));
    }

    @PutMapping("/{id}")
    public StudyProgress update(@PathVariable String id, @RequestBody StudyProgress item) {
        return service.update(id, item, CurrentUser.id());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        service.delete(id, CurrentUser.id());
        return ResponseEntity.noContent().build();
    }
}
