package com.careertrack.service;

import com.careertrack.dto.CalendarEvent;
import com.careertrack.dto.DashboardResponse;
import com.careertrack.model.Assessment;
import com.careertrack.model.CompetitiveExam;
import com.careertrack.model.GovernmentOpportunity;
import com.careertrack.model.Interview;
import com.careertrack.repository.CompetitiveExamRepository;
import com.careertrack.repository.GovernmentOpportunityRepository;
import com.careertrack.repository.JobApplicationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class DashboardService {

    private final JobApplicationRepository applicationRepository;
    private final InterviewService interviewService;
    private final AssessmentService assessmentService;
    private final GovernmentOpportunityRepository governmentOpportunityRepository;
    private final CompetitiveExamRepository competitiveExamRepository;
    private final NotificationService notificationService;

    private static final int UPCOMING_WINDOW_DAYS = 14;

    public DashboardResponse buildDashboard(String userId) {
        LocalDate today = LocalDate.now();
        LocalDate horizon = today.plusDays(UPCOMING_WINDOW_DAYS);

        List<GovernmentOpportunity> upcomingGovDeadlines = governmentOpportunityRepository.findByUserId(userId).stream()
                .filter(g -> g.getRegistrationDeadline() != null
                        && !g.getRegistrationDeadline().isBefore(today)
                        && !g.getRegistrationDeadline().isAfter(horizon))
                .toList();

        List<CompetitiveExam> upcomingExams = competitiveExamRepository.findByUserId(userId).stream()
                .filter(e -> e.getExamDate() != null
                        && !e.getExamDate().isBefore(today)
                        && !e.getExamDate().isAfter(horizon))
                .toList();

        return DashboardResponse.builder()
                .totalApplications(applicationRepository.countByUserId(userId))
                .applicationsByStatus(countsByStatus(userId))
                .upcomingInterviews(interviewService.upcoming(userId, UPCOMING_WINDOW_DAYS))
                .upcomingAssessments(assessmentService.upcoming(userId, UPCOMING_WINDOW_DAYS))
                .upcomingGovernmentDeadlines(upcomingGovDeadlines)
                .upcomingExams(upcomingExams)
                .unreadNotifications(notificationService.unreadCount(userId))
                .build();
    }

    /** Unified calendar feed across interviews, assessments, gov deadlines and exams (FR-18). */
    public List<CalendarEvent> calendar(String userId, LocalDate from, LocalDate to) {
        List<CalendarEvent> events = new ArrayList<>();

        for (Interview i : interviewService.listForUser(userId)) {
            if (i.getDateTime() != null && inRange(i.getDateTime().toLocalDate(), from, to)) {
                events.add(CalendarEvent.builder()
                        .id(i.getId()).type("INTERVIEW")
                        .title(i.getType() + " interview - " + i.getCompany() + " (" + i.getRole() + ")")
                        .dateTime(i.getDateTime())
                        .relatedEntityId(i.getId())
                        .build());
            }
        }

        for (Assessment a : assessmentService.listForUser(userId)) {
            if (a.getDeadline() != null && inRange(a.getDeadline().toLocalDate(), from, to)) {
                events.add(CalendarEvent.builder()
                        .id(a.getId()).type("ASSESSMENT")
                        .title(a.getType() + " due - " + a.getCompany() + " (" + a.getRole() + ")")
                        .dateTime(a.getDeadline())
                        .relatedEntityId(a.getId())
                        .build());
            }
        }

        for (GovernmentOpportunity g : governmentOpportunityRepository.findByUserId(userId)) {
            if (g.getRegistrationDeadline() != null && inRange(g.getRegistrationDeadline(), from, to)) {
                events.add(CalendarEvent.builder()
                        .id(g.getId() + "-reg").type("GOVERNMENT_DEADLINE")
                        .title("Registration deadline - " + g.getTitle())
                        .dateTime(g.getRegistrationDeadline().atStartOfDay())
                        .relatedEntityId(g.getId())
                        .build());
            }
            if (g.getExamDate() != null && inRange(g.getExamDate(), from, to)) {
                events.add(CalendarEvent.builder()
                        .id(g.getId() + "-exam").type("GOVERNMENT_DEADLINE")
                        .title("Exam date - " + g.getTitle())
                        .dateTime(g.getExamDate().atStartOfDay())
                        .relatedEntityId(g.getId())
                        .build());
            }
        }

        for (CompetitiveExam e : competitiveExamRepository.findByUserId(userId)) {
            if (e.getExamDate() != null && inRange(e.getExamDate(), from, to)) {
                events.add(CalendarEvent.builder()
                        .id(e.getId() + "-exam").type("EXAM")
                        .title(e.getExamName() + " exam date")
                        .dateTime(e.getExamDate().atStartOfDay())
                        .relatedEntityId(e.getId())
                        .build());
            }
            if (e.getRegistrationDeadline() != null && inRange(e.getRegistrationDeadline(), from, to)) {
                events.add(CalendarEvent.builder()
                        .id(e.getId() + "-reg").type("EXAM_REGISTRATION")
                        .title(e.getExamName() + " registration deadline")
                        .dateTime(e.getRegistrationDeadline().atStartOfDay())
                        .relatedEntityId(e.getId())
                        .build());
            }
        }

        events.sort((x, y) -> x.getDateTime().compareTo(y.getDateTime()));
        return events;
    }

    private boolean inRange(LocalDate date, LocalDate from, LocalDate to) {
        return !date.isBefore(from) && !date.isAfter(to);
    }

    private java.util.Map<com.careertrack.model.ApplicationStatus, Long> countsByStatus(String userId) {
        return java.util.Arrays.stream(com.careertrack.model.ApplicationStatus.values())
                .collect(java.util.stream.Collectors.toMap(
                        s -> s,
                        s -> applicationRepository.countByUserIdAndStatus(userId, s)
                ));
    }
}
