package com.careertrack.repository;

import com.careertrack.model.Notification;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;

public interface NotificationRepository extends MongoRepository<Notification, String> {
    List<Notification> findByUserIdOrderByCreatedAtDesc(String userId);
    List<Notification> findByUserIdAndIsReadFalseOrderByCreatedAtDesc(String userId);
    Optional<Notification> findByIdAndUserId(String id, String userId);
    long countByUserIdAndIsReadFalse(String userId);
    boolean existsByUserIdAndRelatedEntityIdAndType(String userId, String relatedEntityId, com.careertrack.model.NotificationType type);
}
