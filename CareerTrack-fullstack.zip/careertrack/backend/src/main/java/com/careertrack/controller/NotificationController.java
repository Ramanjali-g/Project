package com.careertrack.controller;

import com.careertrack.model.Notification;
import com.careertrack.security.CurrentUser;
import com.careertrack.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
public class NotificationController {

    private final NotificationService notificationService;

    @GetMapping
    public List<Notification> list(@RequestParam(required = false, defaultValue = "false") boolean unreadOnly) {
        return notificationService.listForUser(CurrentUser.id(), unreadOnly);
    }

    @GetMapping("/unread-count")
    public Map<String, Long> unreadCount() {
        return Map.of("count", notificationService.unreadCount(CurrentUser.id()));
    }

    @PutMapping("/{id}/read")
    public Notification markRead(@PathVariable String id) {
        return notificationService.markRead(id, CurrentUser.id());
    }

    @PutMapping("/read-all")
    public ResponseEntity<Void> markAllRead() {
        notificationService.markAllRead(CurrentUser.id());
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        notificationService.delete(id, CurrentUser.id());
        return ResponseEntity.noContent().build();
    }
}
