package com.careertrack.repository;

import com.careertrack.model.ApplicationStatus;
import com.careertrack.model.JobApplication;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;

public interface JobApplicationRepository extends MongoRepository<JobApplication, String> {
    List<JobApplication> findByUserId(String userId);
    List<JobApplication> findByUserIdAndStatus(String userId, ApplicationStatus status);
    Optional<JobApplication> findByIdAndUserId(String id, String userId);
    long countByUserId(String userId);
    long countByUserIdAndStatus(String userId, ApplicationStatus status);
}
