package com.careertrack.model;

public enum ApplicationType {
    JOB,
    INTERNSHIP
}
