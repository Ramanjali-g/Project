package com.careertrack.repository;

import com.careertrack.model.Assessment;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface AssessmentRepository extends MongoRepository<Assessment, String> {
    List<Assessment> findByUserId(String userId);
    Optional<Assessment> findByIdAndUserId(String id, String userId);
    List<Assessment> findByUserIdAndDeadlineBetween(String userId, LocalDateTime from, LocalDateTime to);
    List<Assessment> findByApplicationId(String applicationId);
}
