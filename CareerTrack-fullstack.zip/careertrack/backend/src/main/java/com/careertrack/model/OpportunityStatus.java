package com.careertrack.model;

public enum OpportunityStatus {
    UPCOMING,
    OPEN,
    CLOSED,
    RESULT_DECLARED
}
