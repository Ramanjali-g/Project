package com.careertrack.controller;

import com.careertrack.model.Opportunity;
import com.careertrack.model.OpportunityCategory;
import com.careertrack.service.OpportunityService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/opportunities")
@RequiredArgsConstructor
public class OpportunityController {

    private final OpportunityService opportunityService;

    /** FR-22: search & filtering by role/type/location. */
    @GetMapping
    public List<Opportunity> search(
            @RequestParam(required = false) OpportunityCategory category,
            @RequestParam(required = false) String role,
            @RequestParam(required = false) String location
    ) {
        return opportunityService.search(category, role, location);
    }

    /** FR-16: personalized relevance-scored feed for the current user. */
    @GetMapping("/for-me")
    public List<OpportunityService.OpportunityMatch> forMe() {
        return opportunityService.personalizedFeed(com.careertrack.security.CurrentUser.id(), 20);
    }

    @GetMapping("/{id}")
    public Opportunity get(@PathVariable String id) {
        return opportunityService.get(id);
    }

    @PostMapping
    public ResponseEntity<Opportunity> create(@RequestBody Opportunity opportunity) {
        return ResponseEntity.ok(opportunityService.create(opportunity));
    }

    @PutMapping("/{id}")
    public Opportunity update(@PathVariable String id, @RequestBody Opportunity opportunity) {
        return opportunityService.update(id, opportunity);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        opportunityService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
