package com.careertrack.dto;

import com.careertrack.model.ApplicationStatus;
import com.careertrack.model.EmailEventType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EmailExtractionResult {
    private String company;
    private String role;
    private EmailEventType eventType;
    private ApplicationStatus proposedStatus;
    private LocalDateTime eventDateTime;
    private LocalDateTime deadline;
    private double confidence;
    private String method; // "llm" or "heuristic" - which extractor produced this
}
