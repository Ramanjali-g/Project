package com.careertrack.model;

public enum AssessmentStatus {
    PENDING,
    COMPLETED,
    MISSED
}
