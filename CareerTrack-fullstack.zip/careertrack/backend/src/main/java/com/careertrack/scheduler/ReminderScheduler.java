package com.careertrack.scheduler;

import com.careertrack.model.*;
import com.careertrack.repository.*;
import com.careertrack.service.NotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * FR-19: notifies users about important upcoming deadlines, interviews,
 * assessments and exams. Runs once a day; each reminder is only created
 * once per entity (see NotificationService#createIfAbsent) so re-runs
 * don't spam duplicate notifications.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ReminderScheduler {

    private static final int REMINDER_WINDOW_DAYS = 2;

    private final UserRepository userRepository;
    private final InterviewRepository interviewRepository;
    private final AssessmentRepository assessmentRepository;
    private final GovernmentOpportunityRepository governmentOpportunityRepository;
    private final CompetitiveExamRepository competitiveExamRepository;
    private final NotificationService notificationService;

    @Scheduled(cron = "0 0 7 * * *") // every day at 07:00 server time
    public void sendDailyReminders() {
        for (User user : userRepository.findAll()) {
            remindInterviews(user.getId());
            remindAssessments(user.getId());
            remindGovernmentDeadlines(user.getId());
            remindExams(user.getId());
        }
    }

    private void remindInterviews(String userId) {
        LocalDateTime now = LocalDateTime.now();
        for (Interview i : interviewRepository.findByUserIdAndDateTimeBetween(userId, now, now.plusDays(REMINDER_WINDOW_DAYS))) {
            notificationService.createIfAbsent(
                    userId,
                    "Upcoming interview",
                    i.getType() + " interview at " + i.getCompany() + " on " + i.getDateTime(),
                    NotificationType.INTERVIEW,
                    i.getId()
            );
        }
    }

    private void remindAssessments(String userId) {
        LocalDateTime now = LocalDateTime.now();
        for (Assessment a : assessmentRepository.findByUserIdAndDeadlineBetween(userId, now, now.plusDays(REMINDER_WINDOW_DAYS))) {
            notificationService.createIfAbsent(
                    userId,
                    "Assessment deadline approaching",
                    a.getType() + " for " + a.getCompany() + " is due " + a.getDeadline(),
                    NotificationType.ASSESSMENT,
                    a.getId()
            );
        }
    }

    private void remindGovernmentDeadlines(String userId) {
        LocalDate today = LocalDate.now();
        LocalDate horizon = today.plusDays(REMINDER_WINDOW_DAYS);
        for (GovernmentOpportunity g : governmentOpportunityRepository.findByUserId(userId)) {
            if (g.getRegistrationDeadline() != null && !g.getRegistrationDeadline().isBefore(today) && !g.getRegistrationDeadline().isAfter(horizon)) {
                notificationService.createIfAbsent(
                        userId,
                        "Registration deadline approaching",
                        g.getTitle() + " registration closes on " + g.getRegistrationDeadline(),
                        NotificationType.DEADLINE,
                        g.getId()
                );
            }
        }
    }

    private void remindExams(String userId) {
        LocalDate today = LocalDate.now();
        LocalDate horizon = today.plusDays(REMINDER_WINDOW_DAYS);
        for (CompetitiveExam e : competitiveExamRepository.findByUserId(userId)) {
            if (e.getExamDate() != null && !e.getExamDate().isBefore(today) && !e.getExamDate().isAfter(horizon)) {
                notificationService.createIfAbsent(
                        userId,
                        "Exam coming up",
                        e.getExamName() + " is scheduled for " + e.getExamDate(),
                        NotificationType.EXAM,
                        e.getId()
                );
            }
        }
    }
}
