package com.careertrack.scheduler;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Extension point for FR-10 (Opportunity Aggregation) / section 8 (External
 * Data Sources).
 *
 * This MVP does NOT scrape or poll any third-party site out of the box,
 * because a real implementation needs to (a) pick specific official/
 * authorized sources per opportunity type, and (b) respect each source's
 * terms of use / API agreement - both are deployment-specific decisions.
 *
 * To wire up a real collector:
 *   1. Set app.opportunity-collector.enabled=true (see application.yml)
 *   2. Implement one method per source below, calling OpportunityService.create()
 *      (or update(), to refresh sourceUrl/lastCheckedAt on existing entries)
 *      with data pulled from that source's official/authorized API.
 *   3. Keep verified=true only for sources you can actually vouch for
 *      (FR-11: each aggregated opportunity retains its source information).
 */
@Slf4j
@Component
public class OpportunityCollectorScheduler {

    @Value("${app.opportunity-collector.enabled:false}")
    private boolean enabled;

    @Scheduled(cron = "0 30 6 * * *") // daily at 06:30, no-op unless enabled
    public void collect() {
        if (!enabled) {
            return;
        }
        log.info("Opportunity collector is enabled but no source implementations have been added yet. " +
                "See OpportunityCollectorScheduler's class-level Javadoc for how to add one.");
        // Example extension point:
        // collectFromOfficialGovernmentSource();
        // collectFromAuthorizedJobApi();
    }
}
