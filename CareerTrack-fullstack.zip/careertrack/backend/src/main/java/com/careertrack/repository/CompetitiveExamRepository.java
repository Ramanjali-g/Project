package com.careertrack.repository;

import com.careertrack.model.CompetitiveExam;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;

public interface CompetitiveExamRepository extends MongoRepository<CompetitiveExam, String> {
    List<CompetitiveExam> findByUserId(String userId);
    Optional<CompetitiveExam> findByIdAndUserId(String id, String userId);
}
