package com.careertrack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class CareerTrackApplication {
    public static void main(String[] args) {
        SpringApplication.run(CareerTrackApplication.class, args);
    }
}
