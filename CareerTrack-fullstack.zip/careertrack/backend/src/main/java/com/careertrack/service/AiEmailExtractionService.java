package com.careertrack.service;

import com.careertrack.dto.EmailExtractionResult;
import com.careertrack.model.ApplicationStatus;
import com.careertrack.model.EmailEventType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Implements FR-12/FR-13/section 7: extracts a structured career event from an
 * authorized email's raw text.
 *
 * Per the AI Safety requirement (7.3), the output of this service is always
 * treated as *proposed* information by the caller (EmailEventService) - it is
 * never written directly onto a JobApplication without a confirmation step
 * for ambiguous/low-confidence results (see EmailEventController#confirm).
 *
 * Two extraction strategies are supported:
 *  1. LLM-backed (used when app.ai.anthropic-api-key is configured): calls the
 *     Anthropic Messages API and asks for strict JSON output.
 *  2. Heuristic fallback (used otherwise, so the feature works out of the box
 *     with zero configuration): simple keyword/regex matching against the
 *     phrasing shown in the SRS example (section 7.2).
 */
@Slf4j
@Service
public class AiEmailExtractionService {

    private final RestClient restClient;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Value("${app.ai.anthropic-api-key:}")
    private String anthropicApiKey;

    @Value("${app.ai.anthropic-model:claude-sonnet-4-6}")
    private String anthropicModel;

    public AiEmailExtractionService(RestClient.Builder restClientBuilder) {
        this.restClient = restClientBuilder.baseUrl("https://api.anthropic.com").build();
    }

    public EmailExtractionResult extract(String emailText) {
        if (anthropicApiKey != null && !anthropicApiKey.isBlank()) {
            try {
                return extractWithLlm(emailText);
            } catch (Exception ex) {
                log.warn("LLM extraction failed, falling back to heuristic extractor: {}", ex.getMessage());
            }
        }
        return extractHeuristically(emailText);
    }

    // ---------------------------------------------------------------
    // Strategy 1: LLM-backed extraction (Anthropic Messages API)
    // ---------------------------------------------------------------

    private EmailExtractionResult extractWithLlm(String emailText) {
        String prompt = """
                Extract a structured career-related event from the email below.
                Respond with ONLY a JSON object (no markdown, no commentary) with exactly these fields:
                {
                  "company": string or null,
                  "role": string or null,
                  "eventType": one of ["APPLICATION_RECEIVED","ASSESSMENT","SHORTLISTED","TECHNICAL_INTERVIEW","HR_INTERVIEW","OFFER","SELECTED","REJECTED","DEADLINE_REMINDER","EXAM_NOTIFICATION","UNKNOWN"],
                  "proposedStatus": one of ["INTERESTED","APPLIED","ASSESSMENT","SHORTLISTED","INTERVIEW","OFFER","SELECTED","REJECTED","WITHDRAWN"] or null,
                  "eventDateTime": ISO-8601 local date-time string or null,
                  "deadline": ISO-8601 local date-time string or null,
                  "confidence": number between 0 and 1
                }

                Email:
                ---
                %s
                ---
                """.formatted(emailText);

        Map<String, Object> body = Map.of(
                "model", anthropicModel,
                "max_tokens", 500,
                "messages", List.of(Map.of("role", "user", "content", prompt))
        );

        JsonNode response = restClient.post()
                .uri("/v1/messages")
                .header("x-api-key", anthropicApiKey)
                .header("anthropic-version", "2023-06-01")
                .header("content-type", "application/json")
                .body(body)
                .retrieve()
                .body(JsonNode.class);

        String text = response.path("content").get(0).path("text").asText("{}");
        JsonNode json = parseJsonLoose(text);

        return EmailExtractionResult.builder()
                .company(textOrNull(json, "company"))
                .role(textOrNull(json, "role"))
                .eventType(enumOrDefault(EmailEventType.class, textOrNull(json, "eventType"), EmailEventType.UNKNOWN))
                .proposedStatus(enumOrDefault(ApplicationStatus.class, textOrNull(json, "proposedStatus"), null))
                .eventDateTime(dateTimeOrNull(textOrNull(json, "eventDateTime")))
                .deadline(dateTimeOrNull(textOrNull(json, "deadline")))
                .confidence(json.path("confidence").asDouble(0.5))
                .method("llm")
                .build();
    }

    private JsonNode parseJsonLoose(String text) {
        try {
            // Strip accidental markdown code fences if the model added them anyway.
            String cleaned = text.trim();
            if (cleaned.startsWith("```")) {
                cleaned = cleaned.replaceAll("^```[a-zA-Z]*", "").replaceAll("```$", "").trim();
            }
            return objectMapper.readTree(cleaned);
        } catch (Exception e) {
            return objectMapper.createObjectNode();
        }
    }

    private String textOrNull(JsonNode node, String field) {
        JsonNode v = node.get(field);
        return (v == null || v.isNull()) ? null : v.asText();
    }

    private <T extends Enum<T>> T enumOrDefault(Class<T> type, String value, T fallback) {
        if (value == null || value.isBlank()) return fallback;
        try {
            return Enum.valueOf(type, value.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return fallback;
        }
    }

    private LocalDateTime dateTimeOrNull(String value) {
        if (value == null || value.isBlank()) return null;
        try {
            return LocalDateTime.parse(value.length() == 10 ? value + "T00:00:00" : value);
        } catch (Exception e) {
            return null;
        }
    }

    // ---------------------------------------------------------------
    // Strategy 2: heuristic fallback (no external API required)
    // ---------------------------------------------------------------

    private static final Map<Pattern, EmailEventType> EVENT_PATTERNS = Map.ofEntries(
            Map.entry(Pattern.compile("shortlisted", Pattern.CASE_INSENSITIVE), EmailEventType.SHORTLISTED),
            Map.entry(Pattern.compile("technical interview", Pattern.CASE_INSENSITIVE), EmailEventType.TECHNICAL_INTERVIEW),
            Map.entry(Pattern.compile("hr interview|hr round", Pattern.CASE_INSENSITIVE), EmailEventType.HR_INTERVIEW),
            Map.entry(Pattern.compile("\\boffer\\b", Pattern.CASE_INSENSITIVE), EmailEventType.OFFER),
            Map.entry(Pattern.compile("selected|congratulations.*hired", Pattern.CASE_INSENSITIVE), EmailEventType.SELECTED),
            Map.entry(Pattern.compile("regret|unfortunately|not (been )?selected|rejected", Pattern.CASE_INSENSITIVE), EmailEventType.REJECTED),
            Map.entry(Pattern.compile("assessment|online test|coding test|hackerrank|hackerearth", Pattern.CASE_INSENSITIVE), EmailEventType.ASSESSMENT),
            Map.entry(Pattern.compile("deadline|last date|apply before", Pattern.CASE_INSENSITIVE), EmailEventType.DEADLINE_REMINDER),
            Map.entry(Pattern.compile("exam date|admit card|notification", Pattern.CASE_INSENSITIVE), EmailEventType.EXAM_NOTIFICATION),
            Map.entry(Pattern.compile("application (has been )?received|thank you for applying", Pattern.CASE_INSENSITIVE), EmailEventType.APPLICATION_RECEIVED)
    );

    private static final Map<EmailEventType, ApplicationStatus> DEFAULT_STATUS_FOR_EVENT = Map.of(
            EmailEventType.APPLICATION_RECEIVED, ApplicationStatus.APPLIED,
            EmailEventType.ASSESSMENT, ApplicationStatus.ASSESSMENT,
            EmailEventType.SHORTLISTED, ApplicationStatus.SHORTLISTED,
            EmailEventType.TECHNICAL_INTERVIEW, ApplicationStatus.INTERVIEW,
            EmailEventType.HR_INTERVIEW, ApplicationStatus.INTERVIEW,
            EmailEventType.OFFER, ApplicationStatus.OFFER,
            EmailEventType.SELECTED, ApplicationStatus.SELECTED,
            EmailEventType.REJECTED, ApplicationStatus.REJECTED
    );

    EmailExtractionResult extractHeuristically(String emailText) {
        EmailEventType eventType = EmailEventType.UNKNOWN;
        for (var entry : EVENT_PATTERNS.entrySet()) {
            if (entry.getKey().matcher(emailText).find()) {
                eventType = entry.getValue();
                break;
            }
        }

        String company = guessCompany(emailText);
        String role = guessRole(emailText);
        ApplicationStatus proposedStatus = DEFAULT_STATUS_FOR_EVENT.get(eventType);

        double confidence = eventType == EmailEventType.UNKNOWN ? 0.2 : (company != null ? 0.6 : 0.45);

        return EmailExtractionResult.builder()
                .company(company)
                .role(role)
                .eventType(eventType)
                .proposedStatus(proposedStatus)
                .eventDateTime(null) // heuristic extractor does not attempt free-text date parsing
                .deadline(null)
                .confidence(confidence)
                .method("heuristic")
                .build();
    }

    private String guessCompany(String text) {
        // Looks for "at <Company>" or "from <Company>" - a lightweight heuristic only.
        Matcher m = Pattern.compile("\\b(?:at|from|with)\\s+([A-Z][A-Za-z0-9&.\\- ]{1,40}?)(?:[.,!\\n]|\\s+(?:for|regarding|team))", Pattern.MULTILINE)
                .matcher(text);
        if (m.find()) {
            return m.group(1).trim();
        }
        return null;
    }

    private String guessRole(String text) {
        Matcher m = Pattern.compile("\\bfor the\\s+([A-Za-z0-9&.+#\\- ]{2,50}?)\\s+(?:role|position|internship|interview)", Pattern.CASE_INSENSITIVE)
                .matcher(text);
        if (m.find()) {
            return m.group(1).trim();
        }
        return null;
    }
}
