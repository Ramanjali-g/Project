package com.careertrack.controller;

import com.careertrack.dto.CalendarEvent;
import com.careertrack.dto.DashboardResponse;
import com.careertrack.security.CurrentUser;
import com.careertrack.service.DashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class DashboardController {

    private final DashboardService dashboardService;

    @GetMapping("/dashboard")
    public DashboardResponse dashboard() {
        return dashboardService.buildDashboard(CurrentUser.id());
    }

    @GetMapping("/calendar")
    public List<CalendarEvent> calendar(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to
    ) {
        return dashboardService.calendar(CurrentUser.id(), from, to);
    }
}
