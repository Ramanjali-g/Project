package com.careertrack.controller;

import com.careertrack.model.ApplicationStatus;
import com.careertrack.model.JobApplication;
import com.careertrack.security.CurrentUser;
import com.careertrack.service.JobApplicationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/applications")
@RequiredArgsConstructor
public class JobApplicationController {

    private final JobApplicationService applicationService;

    @GetMapping
    public List<JobApplication> list(@RequestParam(required = false) ApplicationStatus status) {
        return applicationService.listForUser(CurrentUser.id(), status);
    }

    @GetMapping("/{id}")
    public JobApplication get(@PathVariable String id) {
        return applicationService.get(id, CurrentUser.id());
    }

    @PostMapping
    public ResponseEntity<JobApplication> create(@RequestBody JobApplication application) {
        return ResponseEntity.ok(applicationService.create(application, CurrentUser.id()));
    }

    @PutMapping("/{id}")
    public JobApplication update(@PathVariable String id, @RequestBody JobApplication application) {
        return applicationService.update(id, application, CurrentUser.id());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        applicationService.delete(id, CurrentUser.id());
        return ResponseEntity.noContent().build();
    }
}
