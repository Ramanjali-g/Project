package com.careertrack.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.time.LocalDate;

/**
 * A normalized, aggregated opportunity (job / internship / government / exam)
 * collected from official or authorized external sources (FR-10, FR-11, section 8).
 *
 * In this MVP, records are created via the /api/opportunities endpoint (manually,
 * by an admin/import script, or by a future scheduled collector - see
 * scheduler/OpportunityCollectorScheduler.java for the extension point). No
 * live scraping of third-party sites is performed by default because that
 * requires choosing specific authorized sources/APIs and credentials that
 * are deployment-specific.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "opportunities")
public class Opportunity {

    @Id
    private String id;

    private String title;
    private OpportunityCategory category;
    private String organization;
    private String location;
    private String description;

    @Indexed
    private String role; // for search/filter (FR-22)

    private String eligibility;
    private LocalDate publishedDate;
    private LocalDate deadline;

    private String sourceName;
    private String sourceUrl;
    private boolean verified;
    private Instant lastCheckedAt;

    @CreatedDate
    private Instant createdAt;
}
