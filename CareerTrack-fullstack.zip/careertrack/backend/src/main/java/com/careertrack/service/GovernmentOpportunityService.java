package com.careertrack.service;

import com.careertrack.exception.ResourceNotFoundException;
import com.careertrack.model.GovernmentOpportunity;
import com.careertrack.repository.GovernmentOpportunityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class GovernmentOpportunityService {

    private final GovernmentOpportunityRepository repository;

    public List<GovernmentOpportunity> listForUser(String userId) {
        return repository.findByUserId(userId);
    }

    public GovernmentOpportunity get(String id, String userId) {
        return repository.findByIdAndUserId(id, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Government opportunity not found"));
    }

    public GovernmentOpportunity create(GovernmentOpportunity item, String userId) {
        item.setId(null);
        item.setUserId(userId);
        return repository.save(item);
    }

    public GovernmentOpportunity update(String id, GovernmentOpportunity updates, String userId) {
        GovernmentOpportunity existing = get(id, userId);
        existing.setTitle(updates.getTitle());
        existing.setOrganization(updates.getOrganization());
        existing.setEligibility(updates.getEligibility());
        existing.setNotificationDate(updates.getNotificationDate());
        existing.setRegistrationDeadline(updates.getRegistrationDeadline());
        existing.setExamDate(updates.getExamDate());
        existing.setResultDate(updates.getResultDate());
        existing.setStatus(updates.getStatus());
        existing.setSourceUrl(updates.getSourceUrl());
        existing.setSourceName(updates.getSourceName());
        existing.setNotes(updates.getNotes());
        return repository.save(existing);
    }

    public void delete(String id, String userId) {
        repository.delete(get(id, userId));
    }
}
