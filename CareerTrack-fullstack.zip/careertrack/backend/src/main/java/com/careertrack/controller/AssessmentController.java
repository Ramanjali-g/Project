package com.careertrack.controller;

import com.careertrack.model.Assessment;
import com.careertrack.security.CurrentUser;
import com.careertrack.service.AssessmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/assessments")
@RequiredArgsConstructor
public class AssessmentController {

    private final AssessmentService assessmentService;

    @GetMapping
    public List<Assessment> list() {
        return assessmentService.listForUser(CurrentUser.id());
    }

    @GetMapping("/{id}")
    public Assessment get(@PathVariable String id) {
        return assessmentService.get(id, CurrentUser.id());
    }

    @PostMapping
    public ResponseEntity<Assessment> create(@RequestBody Assessment assessment) {
        return ResponseEntity.ok(assessmentService.create(assessment, CurrentUser.id()));
    }

    @PutMapping("/{id}")
    public Assessment update(@PathVariable String id, @RequestBody Assessment assessment) {
        return assessmentService.update(id, assessment, CurrentUser.id());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        assessmentService.delete(id, CurrentUser.id());
        return ResponseEntity.noContent().build();
    }
}
