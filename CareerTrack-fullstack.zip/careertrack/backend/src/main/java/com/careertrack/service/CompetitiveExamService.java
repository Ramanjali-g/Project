package com.careertrack.service;

import com.careertrack.exception.ResourceNotFoundException;
import com.careertrack.model.CompetitiveExam;
import com.careertrack.repository.CompetitiveExamRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CompetitiveExamService {

    private final CompetitiveExamRepository repository;

    public List<CompetitiveExam> listForUser(String userId) {
        return repository.findByUserId(userId);
    }

    public CompetitiveExam get(String id, String userId) {
        return repository.findByIdAndUserId(id, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Competitive exam not found"));
    }

    public CompetitiveExam create(CompetitiveExam item, String userId) {
        item.setId(null);
        item.setUserId(userId);
        return repository.save(item);
    }

    public CompetitiveExam update(String id, CompetitiveExam updates, String userId) {
        CompetitiveExam existing = get(id, userId);
        existing.setExamName(updates.getExamName());
        existing.setRegistrationDeadline(updates.getRegistrationDeadline());
        existing.setAdmitCardDate(updates.getAdmitCardDate());
        existing.setExamDate(updates.getExamDate());
        existing.setResultDate(updates.getResultDate());
        existing.setTargetScore(updates.getTargetScore());
        existing.setActualScore(updates.getActualScore());
        existing.setStatus(updates.getStatus());
        existing.setNotes(updates.getNotes());
        return repository.save(existing);
    }

    public void delete(String id, String userId) {
        repository.delete(get(id, userId));
    }
}
