package com.careertrack.controller;

import com.careertrack.model.CompetitiveExam;
import com.careertrack.security.CurrentUser;
import com.careertrack.service.CompetitiveExamService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/competitive-exams")
@RequiredArgsConstructor
public class CompetitiveExamController {

    private final CompetitiveExamService service;

    @GetMapping
    public List<CompetitiveExam> list() {
        return service.listForUser(CurrentUser.id());
    }

    @GetMapping("/{id}")
    public CompetitiveExam get(@PathVariable String id) {
        return service.get(id, CurrentUser.id());
    }

    @PostMapping
    public ResponseEntity<CompetitiveExam> create(@RequestBody CompetitiveExam item) {
        return ResponseEntity.ok(service.create(item, CurrentUser.id()));
    }

    @PutMapping("/{id}")
    public CompetitiveExam update(@PathVariable String id, @RequestBody CompetitiveExam item) {
        return service.update(id, item, CurrentUser.id());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        service.delete(id, CurrentUser.id());
        return ResponseEntity.noContent().build();
    }
}
