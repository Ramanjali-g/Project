package com.careertrack.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.time.LocalDateTime;

/**
 * A structured career event extracted (by AI or heuristics) from an
 * authorized email message (FR-12, FR-13, section 7). Per FR-14 and the
 * AI Safety requirements (7.3), extracted events are stored as *proposed*
 * information - applying them to a JobApplication requires an explicit
 * confirm step (see EmailEventController#confirm), unless the confidence
 * is high and the change is non-destructive.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "emailEvents")
public class EmailEvent {

    @Id
    private String id;

    @Indexed
    private String userId;

    /** Raw source text/subject the event was extracted from (or a reference to it). */
    private String sourceText;
    private String sourceMessageRef;

    private String company;
    private String role;
    private EmailEventType eventType;
    private ApplicationStatus proposedStatus;
    private LocalDateTime eventDateTime;
    private LocalDateTime deadline;

    /** 0.0 - 1.0 heuristic/LLM confidence. */
    private double confidence;

    /** Whether the user has confirmed applying this event to an application. */
    @Builder.Default
    private boolean confirmed = false;

    /** Application this event was (or will be) applied to, once linked. */
    private String linkedApplicationId;

    @CreatedDate
    private Instant createdAt;
}
