package com.careertrack.model;

public enum NotificationType {
    DEADLINE,
    INTERVIEW,
    ASSESSMENT,
    EXAM,
    OPPORTUNITY,
    GENERAL
}
