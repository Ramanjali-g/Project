package com.careertrack.repository;

import com.careertrack.model.Opportunity;
import com.careertrack.model.OpportunityCategory;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface OpportunityRepository extends MongoRepository<Opportunity, String> {
    List<Opportunity> findByCategory(OpportunityCategory category);
    List<Opportunity> findByRoleContainingIgnoreCase(String role);
    List<Opportunity> findByLocationContainingIgnoreCase(String location);
}
