package com.careertrack.repository;

import com.careertrack.model.Interview;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface InterviewRepository extends MongoRepository<Interview, String> {
    List<Interview> findByUserId(String userId);
    Optional<Interview> findByIdAndUserId(String id, String userId);
    List<Interview> findByUserIdAndDateTimeBetween(String userId, LocalDateTime from, LocalDateTime to);
    List<Interview> findByApplicationId(String applicationId);
}
