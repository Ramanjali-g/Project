package com.careertrack.service;

import com.careertrack.exception.ResourceNotFoundException;
import com.careertrack.model.Assessment;
import com.careertrack.repository.AssessmentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AssessmentService {

    private final AssessmentRepository assessmentRepository;

    public List<Assessment> listForUser(String userId) {
        return assessmentRepository.findByUserId(userId);
    }

    public List<Assessment> upcoming(String userId, int days) {
        LocalDateTime now = LocalDateTime.now();
        return assessmentRepository.findByUserIdAndDeadlineBetween(userId, now, now.plusDays(days));
    }

    public Assessment get(String id, String userId) {
        return assessmentRepository.findByIdAndUserId(id, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Assessment not found"));
    }

    public Assessment create(Assessment assessment, String userId) {
        assessment.setId(null);
        assessment.setUserId(userId);
        if (assessment.getStatus() == null) {
            assessment.setStatus(com.careertrack.model.AssessmentStatus.PENDING);
        }
        return assessmentRepository.save(assessment);
    }

    public Assessment update(String id, Assessment updates, String userId) {
        Assessment existing = get(id, userId);
        existing.setApplicationId(updates.getApplicationId());
        existing.setCompany(updates.getCompany());
        existing.setRole(updates.getRole());
        existing.setType(updates.getType());
        existing.setDeadline(updates.getDeadline());
        existing.setStatus(updates.getStatus());
        existing.setNotes(updates.getNotes());
        return assessmentRepository.save(existing);
    }

    public void delete(String id, String userId) {
        assessmentRepository.delete(get(id, userId));
    }
}
