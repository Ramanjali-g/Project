package com.careertrack.service;

import com.careertrack.dto.EmailExtractionResult;
import com.careertrack.exception.BadRequestException;
import com.careertrack.exception.ResourceNotFoundException;
import com.careertrack.model.EmailEvent;
import com.careertrack.model.JobApplication;
import com.careertrack.repository.EmailEventRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * FR-12/FR-13/FR-14: with explicit authorization (the user pasting/forwarding
 * an email's text - see README for how a real Gmail/Outlook OAuth collector
 * would plug in here instead), the AI extracts a structured event and stores
 * it as a *proposal*. Applying it to a JobApplication always requires an
 * explicit confirm call so uncertain AI output can never silently overwrite
 * a career record (Non-Functional Requirement: Reliability).
 */
@Service
@RequiredArgsConstructor
public class EmailEventService {

    private static final double AUTO_APPLY_CONFIDENCE_THRESHOLD = 0.85;

    private final AiEmailExtractionService aiEmailExtractionService;
    private final EmailEventRepository emailEventRepository;
    private final JobApplicationService jobApplicationService;

    public List<EmailEvent> listForUser(String userId) {
        return emailEventRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }

    public EmailEvent extractAndStore(String userId, String emailText, String sourceMessageRef) {
        if (emailText == null || emailText.isBlank()) {
            throw new BadRequestException("emailText must not be empty");
        }

        EmailExtractionResult result = aiEmailExtractionService.extract(emailText);

        EmailEvent event = EmailEvent.builder()
                .userId(userId)
                .sourceText(emailText)
                .sourceMessageRef(sourceMessageRef)
                .company(result.getCompany())
                .role(result.getRole())
                .eventType(result.getEventType())
                .proposedStatus(result.getProposedStatus())
                .eventDateTime(result.getEventDateTime())
                .deadline(result.getDeadline())
                .confidence(result.getConfidence())
                .confirmed(false)
                .build();

        return emailEventRepository.save(event);
    }

    /**
     * Applies a stored event's proposed status to an existing application (FR-14).
     * The caller (frontend) is expected to have surfaced the proposal to the
     * user first; this method is the explicit "confirm" action.
     */
    public JobApplication confirmAndApply(String eventId, String applicationId, String userId) {
        EmailEvent event = emailEventRepository.findByIdAndUserId(eventId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Email event not found"));

        if (event.getProposedStatus() == null) {
            throw new BadRequestException("This event has no proposed status to apply");
        }

        JobApplication application = jobApplicationService.get(applicationId, userId);
        application.setStatus(event.getProposedStatus());
        JobApplication updated = jobApplicationService.update(applicationId, application, userId);

        event.setConfirmed(true);
        event.setLinkedApplicationId(applicationId);
        emailEventRepository.save(event);

        return updated;
    }

    public void dismiss(String eventId, String userId) {
        EmailEvent event = emailEventRepository.findByIdAndUserId(eventId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Email event not found"));
        emailEventRepository.delete(event);
    }
}
