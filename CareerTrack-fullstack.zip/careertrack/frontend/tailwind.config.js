/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#eef4ff',
          100: '#dbe6fe',
          200: '#bfd3fe',
          300: '#93b4fd',
          400: '#608bfa',
          500: '#3d63f4',
          600: '#2942e8',
          700: '#2233cf',
          800: '#222ba7',
          900: '#212a83',
        },
      },
    },
  },
  plugins: [],
}
