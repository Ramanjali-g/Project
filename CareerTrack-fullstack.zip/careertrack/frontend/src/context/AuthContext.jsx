import { createContext, useContext, useEffect, useState } from 'react'
import { authApi } from '../api/authApi'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const raw = localStorage.getItem('careertrack_user')
    return raw ? JSON.parse(raw) : null
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const token = localStorage.getItem('careertrack_token')
    if (!token) {
      setLoading(false)
      return
    }
    authApi
      .me()
      .then((me) => setUser(me))
      .catch(() => {
        localStorage.removeItem('careertrack_token')
        localStorage.removeItem('careertrack_user')
        setUser(null)
      })
      .finally(() => setLoading(false))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  function persist(authResponse) {
    localStorage.setItem('careertrack_token', authResponse.token)
    const basicUser = {
      id: authResponse.userId,
      name: authResponse.name,
      email: authResponse.email,
      roles: authResponse.roles,
    }
    localStorage.setItem('careertrack_user', JSON.stringify(basicUser))
    setUser(basicUser)
  }

  async function login(email, password) {
    const res = await authApi.login({ email, password })
    persist(res)
    return res
  }

  async function register(name, email, password) {
    const res = await authApi.register({ name, email, password })
    persist(res)
    return res
  }

  function logout() {
    localStorage.removeItem('careertrack_token')
    localStorage.removeItem('careertrack_user')
    setUser(null)
  }

  async function refreshProfile() {
    const me = await authApi.me()
    setUser(me)
    return me
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
