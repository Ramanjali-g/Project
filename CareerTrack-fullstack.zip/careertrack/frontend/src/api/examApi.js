import { makeResourceApi } from './makeResourceApi'
export const examApi = makeResourceApi('/competitive-exams')
