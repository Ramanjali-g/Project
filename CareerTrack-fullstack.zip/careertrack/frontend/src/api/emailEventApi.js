import axiosClient from './axiosClient'

export const emailEventApi = {
  list: () => axiosClient.get('/email-events').then((r) => r.data),
  extract: (data) => axiosClient.post('/email-events/extract', data).then((r) => r.data),
  confirm: (id, applicationId) =>
    axiosClient.post(`/email-events/${id}/confirm`, { applicationId }).then((r) => r.data),
  dismiss: (id) => axiosClient.delete(`/email-events/${id}`).then((r) => r.data),
}
