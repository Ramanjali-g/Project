import axiosClient from './axiosClient'
import { makeResourceApi } from './makeResourceApi'

export const opportunityApi = {
  ...makeResourceApi('/opportunities'),
  forMe: () => axiosClient.get('/opportunities/for-me').then((r) => r.data),
}
