import { makeResourceApi } from './makeResourceApi'
export const assessmentApi = makeResourceApi('/assessments')
