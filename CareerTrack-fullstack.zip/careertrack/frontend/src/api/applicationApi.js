import { makeResourceApi } from './makeResourceApi'
export const applicationApi = makeResourceApi('/applications')
