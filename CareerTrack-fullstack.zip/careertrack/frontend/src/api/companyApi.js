import { makeResourceApi } from './makeResourceApi'
export const companyApi = makeResourceApi('/companies')
