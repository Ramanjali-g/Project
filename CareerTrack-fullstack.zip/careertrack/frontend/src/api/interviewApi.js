import { makeResourceApi } from './makeResourceApi'
export const interviewApi = makeResourceApi('/interviews')
