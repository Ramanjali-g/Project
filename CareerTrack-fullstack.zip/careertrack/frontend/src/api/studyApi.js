import { makeResourceApi } from './makeResourceApi'
export const studyApi = makeResourceApi('/study-progress')
