import axiosClient from './axiosClient'

export function makeResourceApi(basePath) {
  return {
    list: (params) => axiosClient.get(basePath, { params }).then((r) => r.data),
    get: (id) => axiosClient.get(`${basePath}/${id}`).then((r) => r.data),
    create: (data) => axiosClient.post(basePath, data).then((r) => r.data),
    update: (id, data) => axiosClient.put(`${basePath}/${id}`, data).then((r) => r.data),
    remove: (id) => axiosClient.delete(`${basePath}/${id}`).then((r) => r.data),
  }
}
