import { makeResourceApi } from './makeResourceApi'
export const governmentApi = makeResourceApi('/government-opportunities')
