import axiosClient from './axiosClient'

export const authApi = {
  register: (data) => axiosClient.post('/auth/register', data).then((r) => r.data),
  login: (data) => axiosClient.post('/auth/login', data).then((r) => r.data),
  me: () => axiosClient.get('/users/me').then((r) => r.data),
  updateMe: (data) => axiosClient.put('/users/me', data).then((r) => r.data),
}
