import axiosClient from './axiosClient'

export const dashboardApi = {
  get: () => axiosClient.get('/dashboard').then((r) => r.data),
  calendar: (from, to) =>
    axiosClient.get('/calendar', { params: { from, to } }).then((r) => r.data),
}
