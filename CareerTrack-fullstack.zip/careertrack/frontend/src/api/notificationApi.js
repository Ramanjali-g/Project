import axiosClient from './axiosClient'

export const notificationApi = {
  list: (unreadOnly = false) =>
    axiosClient.get('/notifications', { params: { unreadOnly } }).then((r) => r.data),
  unreadCount: () => axiosClient.get('/notifications/unread-count').then((r) => r.data),
  markRead: (id) => axiosClient.put(`/notifications/${id}/read`).then((r) => r.data),
  markAllRead: () => axiosClient.put('/notifications/read-all').then((r) => r.data),
  remove: (id) => axiosClient.delete(`/notifications/${id}`).then((r) => r.data),
}
