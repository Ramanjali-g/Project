export const APPLICATION_STATUSES = [
  'INTERESTED', 'APPLIED', 'ASSESSMENT', 'SHORTLISTED', 'INTERVIEW',
  'OFFER', 'SELECTED', 'REJECTED', 'WITHDRAWN',
]

export const STATUS_COLORS = {
  INTERESTED: 'bg-slate-100 text-slate-700',
  APPLIED: 'bg-blue-100 text-blue-700',
  ASSESSMENT: 'bg-amber-100 text-amber-700',
  SHORTLISTED: 'bg-purple-100 text-purple-700',
  INTERVIEW: 'bg-indigo-100 text-indigo-700',
  OFFER: 'bg-teal-100 text-teal-700',
  SELECTED: 'bg-green-100 text-green-700',
  REJECTED: 'bg-red-100 text-red-700',
  WITHDRAWN: 'bg-gray-200 text-gray-600',
  SCHEDULED: 'bg-blue-100 text-blue-700',
  COMPLETED: 'bg-green-100 text-green-700',
  CANCELLED: 'bg-red-100 text-red-700',
  RESCHEDULED: 'bg-amber-100 text-amber-700',
  PENDING: 'bg-amber-100 text-amber-700',
  MISSED: 'bg-red-100 text-red-700',
  UPCOMING: 'bg-blue-100 text-blue-700',
  OPEN: 'bg-green-100 text-green-700',
  CLOSED: 'bg-gray-200 text-gray-600',
  RESULT_DECLARED: 'bg-purple-100 text-purple-700',
}

export const APPLICATION_TYPES = ['JOB', 'INTERNSHIP']

export const INTERVIEW_TYPES = ['PHONE_SCREEN', 'TECHNICAL', 'HR', 'MANAGERIAL', 'ONSITE', 'VIRTUAL', 'OTHER']
export const INTERVIEW_STATUSES = ['SCHEDULED', 'COMPLETED', 'CANCELLED', 'RESCHEDULED']

export const ASSESSMENT_TYPES = ['CODING_TEST', 'ONLINE_ASSESSMENT', 'ASSIGNMENT', 'APTITUDE_TEST', 'OTHER']
export const ASSESSMENT_STATUSES = ['PENDING', 'COMPLETED', 'MISSED']

export const OPPORTUNITY_STATUSES = ['UPCOMING', 'OPEN', 'CLOSED', 'RESULT_DECLARED']
export const OPPORTUNITY_CATEGORIES = ['JOB', 'INTERNSHIP', 'GOVERNMENT', 'EXAM']

export const COMPETITIVE_EXAM_NAMES = ['GATE', 'CAT', 'GRE', 'GMAT', 'CUET', 'JEE', 'NEET', 'OTHER']
