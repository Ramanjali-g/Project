import { useEffect, useMemo, useState } from 'react'
import {
  startOfMonth, endOfMonth, startOfWeek, endOfWeek, eachDayOfInterval,
  format, isSameMonth, isSameDay, addMonths, subMonths,
} from 'date-fns'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { dashboardApi } from '../api/dashboardApi'
import LoadingSpinner from '../components/common/LoadingSpinner'

const TYPE_COLORS = {
  INTERVIEW: 'bg-indigo-500',
  ASSESSMENT: 'bg-amber-500',
  GOVERNMENT_DEADLINE: 'bg-purple-500',
  EXAM: 'bg-teal-500',
  EXAM_REGISTRATION: 'bg-blue-500',
}

export default function CalendarView() {
  const [month, setMonth] = useState(() => startOfMonth(new Date()))
  const [events, setEvents] = useState([])
  const [loading, setLoading] = useState(true)
  const [selectedDay, setSelectedDay] = useState(null)

  const gridStart = startOfWeek(startOfMonth(month))
  const gridEnd = endOfWeek(endOfMonth(month))
  const days = eachDayOfInterval({ start: gridStart, end: gridEnd })

  useEffect(() => {
    setLoading(true)
    dashboardApi
      .calendar(format(gridStart, 'yyyy-MM-dd'), format(gridEnd, 'yyyy-MM-dd'))
      .then(setEvents)
      .finally(() => setLoading(false))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [month])

  const eventsByDay = useMemo(() => {
    const map = {}
    events.forEach((e) => {
      const key = format(new Date(e.dateTime), 'yyyy-MM-dd')
      map[key] = map[key] || []
      map[key].push(e)
    })
    return map
  }, [events])

  const selectedEvents = selectedDay ? eventsByDay[format(selectedDay, 'yyyy-MM-dd')] || [] : []

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-semibold text-slate-800">Calendar</h1>
          <p className="text-sm text-slate-500 mt-0.5">Interviews, deadlines and exams in one place.</p>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={() => setMonth((m) => subMonths(m, 1))} className="p-1.5 rounded-lg hover:bg-slate-100">
            <ChevronLeft size={18} />
          </button>
          <span className="text-sm font-medium w-32 text-center">{format(month, 'MMMM yyyy')}</span>
          <button onClick={() => setMonth((m) => addMonths(m, 1))} className="p-1.5 rounded-lg hover:bg-slate-100">
            <ChevronRight size={18} />
          </button>
        </div>
      </div>

      {loading ? (
        <LoadingSpinner />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="grid grid-cols-7 text-xs font-medium text-slate-400 border-b border-slate-100">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
                <div key={d} className="px-2 py-2 text-center">{d}</div>
              ))}
            </div>
            <div className="grid grid-cols-7">
              {days.map((day) => {
                const key = format(day, 'yyyy-MM-dd')
                const dayEvents = eventsByDay[key] || []
                const inMonth = isSameMonth(day, month)
                const isSelected = selectedDay && isSameDay(day, selectedDay)
                return (
                  <button
                    key={key}
                    onClick={() => setSelectedDay(day)}
                    className={`h-24 border-b border-r border-slate-100 p-1.5 text-left align-top flex flex-col gap-1 hover:bg-slate-50 ${
                      isSelected ? 'ring-2 ring-inset ring-brand-400' : ''
                    }`}
                  >
                    <span className={`text-xs ${inMonth ? 'text-slate-600' : 'text-slate-300'}`}>
                      {format(day, 'd')}
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {dayEvents.slice(0, 4).map((e) => (
                        <span
                          key={e.id}
                          className={`h-1.5 w-1.5 rounded-full ${TYPE_COLORS[e.type] || 'bg-slate-400'}`}
                          title={e.title}
                        />
                      ))}
                    </div>
                  </button>
                )
              })}
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl p-5">
            <h3 className="font-semibold text-slate-800 text-sm mb-3">
              {selectedDay ? format(selectedDay, 'EEEE, MMM d') : 'Select a day'}
            </h3>
            {selectedDay && selectedEvents.length === 0 && (
              <p className="text-sm text-slate-400">No events on this day.</p>
            )}
            <ul className="space-y-3">
              {selectedEvents.map((e) => (
                <li key={e.id} className="flex items-start gap-2">
                  <span className={`h-2 w-2 rounded-full mt-1.5 ${TYPE_COLORS[e.type] || 'bg-slate-400'}`} />
                  <div>
                    <p className="text-sm text-slate-700">{e.title}</p>
                    <p className="text-xs text-slate-400">{format(new Date(e.dateTime), 'p')}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  )
}
