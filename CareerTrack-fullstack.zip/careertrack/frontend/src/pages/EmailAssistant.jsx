import { useEffect, useState } from 'react'
import { Sparkles, Check, X } from 'lucide-react'
import { emailEventApi } from '../api/emailEventApi'
import { applicationApi } from '../api/applicationApi'
import LoadingSpinner from '../components/common/LoadingSpinner'
import EmptyState from '../components/common/EmptyState'
import StatusBadge from '../components/common/StatusBadge'
import { formatLabel, formatDateTime } from '../utils/format'

export default function EmailAssistant() {
  const [emailText, setEmailText] = useState('')
  const [analyzing, setAnalyzing] = useState(false)
  const [events, setEvents] = useState([])
  const [loadingEvents, setLoadingEvents] = useState(true)
  const [applications, setApplications] = useState([])
  const [error, setError] = useState('')
  const [linkChoice, setLinkChoice] = useState({})

  useEffect(() => {
    refreshEvents()
    applicationApi.list().then(setApplications).catch(() => {})
  }, [])

  function refreshEvents() {
    setLoadingEvents(true)
    emailEventApi
      .list()
      .then(setEvents)
      .finally(() => setLoadingEvents(false))
  }

  async function handleAnalyze(e) {
    e.preventDefault()
    if (!emailText.trim()) return
    setAnalyzing(true)
    setError('')
    try {
      await emailEventApi.extract({ emailText })
      setEmailText('')
      refreshEvents()
    } catch (err) {
      setError(err.response?.data?.message || 'Could not analyze this email.')
    } finally {
      setAnalyzing(false)
    }
  }

  async function handleConfirm(eventId) {
    const applicationId = linkChoice[eventId]
    if (!applicationId) return
    try {
      await emailEventApi.confirm(eventId, applicationId)
      refreshEvents()
    } catch (err) {
      alert(err.response?.data?.message || 'Could not apply this update.')
    }
  }

  async function handleDismiss(eventId) {
    await emailEventApi.dismiss(eventId)
    setEvents((prev) => prev.filter((e) => e.id !== eventId))
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-slate-800">AI Email Assistant</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Paste the text of a career-related email you've received. The AI extracts the company, role,
          event type and a proposed status &mdash; nothing is applied to an application until you confirm it.
        </p>
      </div>

      <form onSubmit={handleAnalyze} className="bg-white border border-slate-200 rounded-xl p-5">
        {error && <p className="text-sm text-red-600 bg-red-50 rounded-lg px-3 py-2 mb-3">{error}</p>}
        <textarea
          rows={6}
          value={emailText}
          onChange={(e) => setEmailText(e.target.value)}
          placeholder='e.g. "Congratulations! You have been shortlisted for the technical interview at Amazon for the SDE Intern role."'
          className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-300"
        />
        <div className="flex justify-end mt-3">
          <button
            type="submit"
            disabled={analyzing || !emailText.trim()}
            className="flex items-center gap-1.5 bg-brand-600 hover:bg-brand-700 text-white text-sm font-medium px-4 py-2 rounded-lg disabled:opacity-60"
          >
            <Sparkles size={16} /> {analyzing ? 'Analyzing…' : 'Analyze Email'}
          </button>
        </div>
      </form>

      <div>
        <h2 className="text-sm font-semibold text-slate-800 mb-3">Extracted events</h2>
        {loadingEvents ? (
          <LoadingSpinner />
        ) : events.length === 0 ? (
          <EmptyState title="No emails analyzed yet" description="Paste an email above to see the extracted event here." />
        ) : (
          <div className="space-y-3">
            {events.map((ev) => (
              <div key={ev.id} className="bg-white border border-slate-200 rounded-xl p-4">
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div>
                    <p className="text-sm font-medium text-slate-800">
                      {formatLabel(ev.eventType)}{ev.company ? ` · ${ev.company}` : ''}{ev.role ? ` · ${ev.role}` : ''}
                    </p>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Extracted via {ev.confidence >= 0.8 ? 'AI' : 'heuristic match'} · confidence {Math.round(ev.confidence * 100)}%
                      {ev.confirmed && ' · Applied'}
                    </p>
                  </div>
                  {ev.proposedStatus && <StatusBadge status={ev.proposedStatus} />}
                </div>

                {!ev.confirmed && ev.proposedStatus && (
                  <div className="flex flex-wrap items-center gap-2 mt-3 pt-3 border-t border-slate-100">
                    <select
                      value={linkChoice[ev.id] || ''}
                      onChange={(e) => setLinkChoice((c) => ({ ...c, [ev.id]: e.target.value }))}
                      className="border border-slate-200 rounded-lg px-2 py-1.5 text-sm bg-white flex-1 min-w-[200px]"
                    >
                      <option value="">Link to application…</option>
                      {applications.map((a) => (
                        <option key={a.id} value={a.id}>
                          {a.role} @ {a.companyName}
                        </option>
                      ))}
                    </select>
                    <button
                      onClick={() => handleConfirm(ev.id)}
                      disabled={!linkChoice[ev.id]}
                      className="flex items-center gap-1 text-xs font-medium bg-green-600 hover:bg-green-700 text-white px-3 py-1.5 rounded-lg disabled:opacity-50"
                    >
                      <Check size={14} /> Confirm & Apply
                    </button>
                    <button
                      onClick={() => handleDismiss(ev.id)}
                      className="flex items-center gap-1 text-xs font-medium text-slate-500 hover:bg-slate-100 px-3 py-1.5 rounded-lg"
                    >
                      <X size={14} /> Dismiss
                    </button>
                  </div>
                )}

                {ev.eventDateTime && (
                  <p className="text-xs text-slate-400 mt-2">Mentioned date/time: {formatDateTime(ev.eventDateTime)}</p>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
