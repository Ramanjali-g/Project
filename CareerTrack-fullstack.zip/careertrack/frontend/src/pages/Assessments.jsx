import ResourcePage from '../components/common/ResourcePage'
import { assessmentApi } from '../api/assessmentApi'
import { ASSESSMENT_STATUSES, ASSESSMENT_TYPES } from '../utils/constants'

const fields = [
  { name: 'company', label: 'Company', type: 'text', required: true },
  { name: 'role', label: 'Role', type: 'text' },
  { name: 'type', label: 'Assessment type', type: 'select', options: ASSESSMENT_TYPES },
  { name: 'deadline', label: 'Deadline', type: 'datetime-local', required: true },
  { name: 'status', label: 'Status', type: 'select', options: ASSESSMENT_STATUSES, default: 'PENDING' },
  { name: 'notes', label: 'Notes', type: 'textarea', colSpan: 2 },
]

const columns = [
  { key: 'company', label: 'Company' },
  { key: 'role', label: 'Role' },
  { key: 'type', label: 'Type' },
  { key: 'deadline', label: 'Deadline' },
  { key: 'status', label: 'Status' },
]

export default function Assessments() {
  return (
    <ResourcePage
      title="Assessments"
      description="Coding tests, online assessments and assignments."
      api={assessmentApi}
      fields={fields}
      columns={columns}
      emptyDescription="Track a coding test or assignment deadline here."
    />
  )
}
