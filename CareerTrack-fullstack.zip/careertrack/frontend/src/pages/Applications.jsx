import { useEffect, useState } from 'react'
import ResourcePage from '../components/common/ResourcePage'
import { applicationApi } from '../api/applicationApi'
import { companyApi } from '../api/companyApi'
import { APPLICATION_STATUSES, APPLICATION_TYPES } from '../utils/constants'
import { Link } from 'react-router-dom'

export default function Applications() {
  const [companies, setCompanies] = useState([])
  const [loadingCompanies, setLoadingCompanies] = useState(true)

  useEffect(() => {
    companyApi
      .list()
      .then(setCompanies)
      .finally(() => setLoadingCompanies(false))
  }, [])

  const fields = [
    {
      name: 'companyId',
      label: 'Company',
      type: 'select',
      required: true,
      options: companies.map((c) => ({ value: c.id, label: c.name })),
    },
    { name: 'role', label: 'Role', type: 'text', required: true },
    { name: 'type', label: 'Type', type: 'select', options: APPLICATION_TYPES, default: 'JOB' },
    { name: 'status', label: 'Status', type: 'select', options: APPLICATION_STATUSES, default: 'INTERESTED' },
    { name: 'location', label: 'Location', type: 'text' },
    { name: 'salary', label: 'Salary / stipend', type: 'number' },
    { name: 'appliedDate', label: 'Applied date', type: 'date' },
    { name: 'jobUrl', label: 'Job posting URL', type: 'text', placeholder: 'https://…' },
    { name: 'notes', label: 'Notes', type: 'textarea', colSpan: 2 },
  ]

  const columns = [
    { key: 'companyName', label: 'Company' },
    { key: 'role', label: 'Role' },
    { key: 'type', label: 'Type' },
    { key: 'status', label: 'Status' },
    { key: 'appliedDate', label: 'Applied' },
  ]

  if (loadingCompanies) return null

  if (companies.length === 0) {
    return (
      <div>
        <h1 className="text-xl font-semibold text-slate-800 mb-2">Applications</h1>
        <p className="text-sm text-slate-500 mb-6">
          Add a company before creating your first application.
        </p>
        <Link
          to="/companies"
          className="inline-block bg-brand-600 hover:bg-brand-700 text-white text-sm font-medium px-4 py-2 rounded-lg"
        >
          Go to Companies
        </Link>
      </div>
    )
  }

  return (
    <ResourcePage
      title="Applications"
      description="Every private job or internship application, from interest to outcome."
      api={applicationApi}
      fields={fields}
      columns={columns}
      emptyDescription="Add your first job or internship application."
    />
  )
}
