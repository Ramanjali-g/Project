import { useEffect, useState } from 'react'
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
  PieChart, Pie, Cell, Legend,
} from 'recharts'
import { dashboardApi } from '../api/dashboardApi'
import { interviewApi } from '../api/interviewApi'
import { studyApi } from '../api/studyApi'
import LoadingSpinner from '../components/common/LoadingSpinner'
import { formatLabel } from '../utils/format'

const PIE_COLORS = ['#3d63f4', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6', '#14b8a6', '#64748b', '#0ea5e9', '#f97316']

export default function Analytics() {
  const [dashboard, setDashboard] = useState(null)
  const [interviews, setInterviews] = useState([])
  const [studyProgress, setStudyProgress] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([dashboardApi.get(), interviewApi.list(), studyApi.list()])
      .then(([d, i, s]) => {
        setDashboard(d)
        setInterviews(i)
        setStudyProgress(s)
      })
      .finally(() => setLoading(false))
  }, [])

  if (loading) return <LoadingSpinner />
  if (!dashboard) return null

  const statusData = Object.entries(dashboard.applicationsByStatus || {})
    .filter(([, count]) => count > 0)
    .map(([status, count]) => ({ name: formatLabel(status), value: count }))

  const interviewStatusCounts = interviews.reduce((acc, i) => {
    acc[i.status] = (acc[i.status] || 0) + 1
    return acc
  }, {})
  const interviewData = Object.entries(interviewStatusCounts).map(([status, count]) => ({
    status: formatLabel(status),
    count,
  }))

  const prepData = studyProgress.map((s) => ({
    subject: s.subject || s.topic || 'Untitled',
    progress: s.progressPercent || 0,
  }))

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-slate-800">Analytics</h1>
        <p className="text-sm text-slate-500 mt-0.5">Application, interview and preparation statistics.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <h3 className="font-semibold text-slate-800 text-sm mb-4">Application funnel</h3>
          {statusData.length === 0 ? (
            <p className="text-sm text-slate-400">No applications yet.</p>
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie data={statusData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label>
                  {statusData.map((entry, index) => (
                    <Cell key={entry.name} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <h3 className="font-semibold text-slate-800 text-sm mb-4">Interviews by status</h3>
          {interviewData.length === 0 ? (
            <p className="text-sm text-slate-400">No interviews logged yet.</p>
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={interviewData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="status" tick={{ fontSize: 11 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                <Tooltip />
                <Bar dataKey="count" fill="#22c55e" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 md:col-span-2">
          <h3 className="font-semibold text-slate-800 text-sm mb-4">Preparation progress by subject</h3>
          {prepData.length === 0 ? (
            <p className="text-sm text-slate-400">No preparation entries yet.</p>
          ) : (
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={prepData} layout="vertical" margin={{ left: 40 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 11 }} />
                <YAxis type="category" dataKey="subject" width={120} tick={{ fontSize: 11 }} />
                <Tooltip />
                <Bar dataKey="progress" fill="#3d63f4" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>
    </div>
  )
}
