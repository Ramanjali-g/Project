import { useEffect, useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { authApi } from '../api/authApi'

function arrToStr(arr) {
  return Array.isArray(arr) ? arr.join(', ') : ''
}
function strToArr(str) {
  return str
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)
}

export default function Profile() {
  const { user, refreshProfile } = useAuth()
  const [form, setForm] = useState({
    name: '', education: '', experience: '', skills: '', preferredRoles: '', preferredLocations: '', examInterests: '',
  })
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState('')

  useEffect(() => {
    authApi
      .me()
      .then((me) => {
        setForm({
          name: me.name || '',
          education: me.profile?.education || '',
          experience: me.profile?.experience || '',
          skills: arrToStr(me.profile?.skills),
          preferredRoles: arrToStr(me.profile?.preferredRoles),
          preferredLocations: arrToStr(me.profile?.preferredLocations),
          examInterests: arrToStr(me.profile?.examInterests),
        })
      })
      .finally(() => setLoading(false))
  }, [])

  async function handleSubmit(e) {
    e.preventDefault()
    setSaving(true)
    setMessage('')
    try {
      await authApi.updateMe({
        name: form.name,
        profile: {
          education: form.education,
          experience: form.experience,
          skills: strToArr(form.skills),
          preferredRoles: strToArr(form.preferredRoles),
          preferredLocations: strToArr(form.preferredLocations),
          examInterests: strToArr(form.examInterests),
        },
      })
      await refreshProfile()
      setMessage('Profile updated.')
    } catch (err) {
      setMessage(err.response?.data?.message || 'Could not save your profile.')
    } finally {
      setSaving(false)
    }
  }

  if (loading) return null

  return (
    <div className="max-w-2xl">
      <h1 className="text-xl font-semibold text-slate-800 mb-1">Profile</h1>
      <p className="text-sm text-slate-500 mb-6">
        Used to personalize opportunity matches (FR-16) and tailor recommendations.
      </p>

      <form onSubmit={handleSubmit} className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
        {message && <p className="text-sm text-brand-700 bg-brand-50 rounded-lg px-3 py-2">{message}</p>}

        <div>
          <label className="block text-xs font-medium text-slate-500 mb-1">Name</label>
          <input
            value={form.name}
            onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
            className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-slate-500 mb-1">Email</label>
          <input value={user?.email || ''} disabled className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm bg-slate-50 text-slate-400" />
        </div>
        <div>
          <label className="block text-xs font-medium text-slate-500 mb-1">Education</label>
          <input
            value={form.education}
            onChange={(e) => setForm((f) => ({ ...f, education: e.target.value }))}
            placeholder="e.g. B.Tech Computer Science, 2026"
            className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-slate-500 mb-1">Experience summary</label>
          <textarea
            rows={2}
            value={form.experience}
            onChange={(e) => setForm((f) => ({ ...f, experience: e.target.value }))}
            placeholder="e.g. 6-month internship as a backend developer"
            className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-slate-500 mb-1">Skills (comma separated)</label>
          <input
            value={form.skills}
            onChange={(e) => setForm((f) => ({ ...f, skills: e.target.value }))}
            placeholder="Java, React, Spring Boot, DSA"
            className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-slate-500 mb-1">Preferred roles (comma separated)</label>
          <input
            value={form.preferredRoles}
            onChange={(e) => setForm((f) => ({ ...f, preferredRoles: e.target.value }))}
            placeholder="SDE Intern, Backend Developer"
            className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-slate-500 mb-1">Preferred locations (comma separated)</label>
          <input
            value={form.preferredLocations}
            onChange={(e) => setForm((f) => ({ ...f, preferredLocations: e.target.value }))}
            placeholder="Bengaluru, Remote"
            className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-slate-500 mb-1">Exam interests (comma separated)</label>
          <input
            value={form.examInterests}
            onChange={(e) => setForm((f) => ({ ...f, examInterests: e.target.value }))}
            placeholder="GATE, CAT"
            className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
          />
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={saving}
            className="bg-brand-600 hover:bg-brand-700 text-white text-sm font-medium px-5 py-2 rounded-lg disabled:opacity-60"
          >
            {saving ? 'Saving…' : 'Save profile'}
          </button>
        </div>
      </form>
    </div>
  )
}
