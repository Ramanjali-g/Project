import { useEffect, useState } from 'react'
import { Check, Trash2 } from 'lucide-react'
import { notificationApi } from '../api/notificationApi'
import LoadingSpinner from '../components/common/LoadingSpinner'
import EmptyState from '../components/common/EmptyState'
import { formatDateTime, formatLabel } from '../utils/format'

export default function Notifications() {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)

  function load() {
    setLoading(true)
    notificationApi.list().then(setItems).finally(() => setLoading(false))
  }

  useEffect(load, [])

  async function markRead(id) {
    await notificationApi.markRead(id)
    setItems((prev) => prev.map((n) => (n.id === id ? { ...n, isRead: true } : n)))
  }

  async function markAllRead() {
    await notificationApi.markAllRead()
    setItems((prev) => prev.map((n) => ({ ...n, isRead: true })))
  }

  async function remove(id) {
    await notificationApi.remove(id)
    setItems((prev) => prev.filter((n) => n.id !== id))
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-semibold text-slate-800">Notifications</h1>
          <p className="text-sm text-slate-500 mt-0.5">Deadlines, interviews and status changes.</p>
        </div>
        <button onClick={markAllRead} className="text-sm font-medium text-brand-600 hover:underline">
          Mark all as read
        </button>
      </div>

      {loading ? (
        <LoadingSpinner />
      ) : items.length === 0 ? (
        <EmptyState title="You're all caught up" description="New reminders and updates will show up here." />
      ) : (
        <div className="space-y-2">
          {items.map((n) => (
            <div
              key={n.id}
              className={`flex items-start justify-between gap-3 border rounded-xl px-4 py-3 ${
                n.isRead ? 'bg-white border-slate-100' : 'bg-brand-50/60 border-brand-100'
              }`}
            >
              <div>
                <p className="text-sm font-medium text-slate-800">{n.title}</p>
                <p className="text-sm text-slate-600 mt-0.5">{n.message}</p>
                <p className="text-xs text-slate-400 mt-1">
                  {formatLabel(n.type)} · {formatDateTime(n.createdAt)}
                </p>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                {!n.isRead && (
                  <button onClick={() => markRead(n.id)} title="Mark as read" className="p-1.5 text-slate-400 hover:text-brand-600">
                    <Check size={16} />
                  </button>
                )}
                <button onClick={() => remove(n.id)} title="Delete" className="p-1.5 text-slate-400 hover:text-red-600">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
