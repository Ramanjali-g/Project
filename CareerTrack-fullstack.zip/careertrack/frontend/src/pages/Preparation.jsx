import ResourcePage from '../components/common/ResourcePage'
import { studyApi } from '../api/studyApi'

const fields = [
  { name: 'examName', label: 'Exam / track', type: 'text', placeholder: 'e.g. GATE' },
  { name: 'subject', label: 'Subject', type: 'text', required: true },
  { name: 'topic', label: 'Topic', type: 'text' },
  { name: 'progressPercent', label: 'Progress (%)', type: 'number' },
  { name: 'mockTestsTaken', label: 'Mock tests taken', type: 'number' },
  { name: 'targetScore', label: 'Target score', type: 'number' },
  { name: 'actualScore', label: 'Actual score', type: 'number' },
  { name: 'notes', label: 'Notes', type: 'textarea', colSpan: 2 },
]

const columns = [
  { key: 'examName', label: 'Exam' },
  { key: 'subject', label: 'Subject' },
  { key: 'topic', label: 'Topic' },
  { key: 'progressPercent', label: 'Progress %' },
  { key: 'mockTestsTaken', label: 'Mock tests' },
]

export default function Preparation() {
  return (
    <ResourcePage
      title="Preparation Tracker"
      description="Subjects, topics, mock tests and target vs actual scores."
      api={studyApi}
      fields={fields}
      columns={columns}
      emptyDescription="Log a subject or topic you're studying for an exam."
    />
  )
}
