import ResourcePage from '../components/common/ResourcePage'
import { governmentApi } from '../api/governmentApi'
import { OPPORTUNITY_STATUSES } from '../utils/constants'

const fields = [
  { name: 'title', label: 'Notification title', type: 'text', required: true },
  { name: 'organization', label: 'Organization', type: 'text', required: true },
  { name: 'eligibility', label: 'Eligibility', type: 'textarea', colSpan: 2 },
  { name: 'notificationDate', label: 'Notification date', type: 'date' },
  { name: 'registrationDeadline', label: 'Registration deadline', type: 'date' },
  { name: 'examDate', label: 'Exam date', type: 'date' },
  { name: 'resultDate', label: 'Result date', type: 'date' },
  { name: 'status', label: 'Status', type: 'select', options: OPPORTUNITY_STATUSES, default: 'UPCOMING' },
  { name: 'sourceName', label: 'Source name', type: 'text', placeholder: 'e.g. Official SSC website' },
  { name: 'sourceUrl', label: 'Source URL', type: 'text', placeholder: 'https://…' },
  { name: 'notes', label: 'Notes', type: 'textarea', colSpan: 2 },
]

const columns = [
  { key: 'title', label: 'Title' },
  { key: 'organization', label: 'Organization' },
  { key: 'registrationDeadline', label: 'Reg. deadline' },
  { key: 'examDate', label: 'Exam date' },
  { key: 'status', label: 'Status' },
]

export default function GovernmentJobs() {
  return (
    <ResourcePage
      title="Government Jobs"
      description="Recruitment notifications, eligibility, and important dates."
      api={governmentApi}
      fields={fields}
      columns={columns}
      emptyDescription="Track a government recruitment notification you're eligible for."
    />
  )
}
