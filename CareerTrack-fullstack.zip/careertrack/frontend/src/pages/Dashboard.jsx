import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'
import { dashboardApi } from '../api/dashboardApi'
import LoadingSpinner from '../components/common/LoadingSpinner'
import StatusBadge from '../components/common/StatusBadge'
import { formatDateTime, formatDate, formatLabel } from '../utils/format'

function StatCard({ label, value, to }) {
  const content = (
    <div className="bg-white border border-slate-200 rounded-xl p-5">
      <p className="text-xs font-medium text-slate-400 uppercase tracking-wide">{label}</p>
      <p className="text-2xl font-semibold text-slate-800 mt-1">{value}</p>
    </div>
  )
  return to ? <Link to={to}>{content}</Link> : content
}

function Section({ title, viewAllTo, children }) {
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-slate-800 text-sm">{title}</h3>
        {viewAllTo && (
          <Link to={viewAllTo} className="text-xs text-brand-600 hover:underline font-medium">
            View all
          </Link>
        )}
      </div>
      {children}
    </div>
  )
}

export default function Dashboard() {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    dashboardApi
      .get()
      .then(setData)
      .catch((e) => setError(e.response?.data?.message || 'Failed to load dashboard.'))
      .finally(() => setLoading(false))
  }, [])

  if (loading) return <LoadingSpinner label="Loading your dashboard…" />
  if (error) return <p className="text-red-600 text-sm">{error}</p>
  if (!data) return null

  const chartData = Object.entries(data.applicationsByStatus || {})
    .filter(([, count]) => count > 0)
    .map(([status, count]) => ({ status: formatLabel(status), count }))

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-slate-800">Dashboard</h1>
        <p className="text-sm text-slate-500 mt-0.5">Your career activity at a glance.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Total Applications" value={data.totalApplications} to="/applications" />
        <StatCard label="Upcoming Interviews" value={data.upcomingInterviews.length} to="/interviews" />
        <StatCard label="Upcoming Assessments" value={data.upcomingAssessments.length} to="/assessments" />
        <StatCard label="Unread Notifications" value={data.unreadNotifications} to="/notifications" />
      </div>

      {chartData.length > 0 && (
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <h3 className="font-semibold text-slate-800 text-sm mb-4">Applications by status</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="status" tick={{ fontSize: 11 }} interval={0} angle={-20} textAnchor="end" height={60} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="count" fill="#3d63f4" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-4">
        <Section title="Upcoming interviews (next 14 days)" viewAllTo="/interviews">
          {data.upcomingInterviews.length === 0 ? (
            <p className="text-sm text-slate-400">Nothing scheduled.</p>
          ) : (
            <ul className="space-y-2">
              {data.upcomingInterviews.map((i) => (
                <li key={i.id} className="flex items-center justify-between text-sm">
                  <span className="text-slate-700">
                    {i.role} @ {i.company}
                  </span>
                  <span className="text-slate-400 text-xs">{formatDateTime(i.dateTime)}</span>
                </li>
              ))}
            </ul>
          )}
        </Section>

        <Section title="Upcoming assessment deadlines" viewAllTo="/assessments">
          {data.upcomingAssessments.length === 0 ? (
            <p className="text-sm text-slate-400">Nothing due soon.</p>
          ) : (
            <ul className="space-y-2">
              {data.upcomingAssessments.map((a) => (
                <li key={a.id} className="flex items-center justify-between text-sm">
                  <span className="text-slate-700">
                    {a.role ? `${a.role} @ ${a.company}` : a.company}
                  </span>
                  <span className="text-slate-400 text-xs">{formatDateTime(a.deadline)}</span>
                </li>
              ))}
            </ul>
          )}
        </Section>

        <Section title="Government deadlines" viewAllTo="/government-jobs">
          {data.upcomingGovernmentDeadlines.length === 0 ? (
            <p className="text-sm text-slate-400">No deadlines in the next 14 days.</p>
          ) : (
            <ul className="space-y-2">
              {data.upcomingGovernmentDeadlines.map((g) => (
                <li key={g.id} className="flex items-center justify-between text-sm">
                  <span className="text-slate-700">{g.title}</span>
                  <span className="text-slate-400 text-xs">{formatDate(g.registrationDeadline)}</span>
                </li>
              ))}
            </ul>
          )}
        </Section>

        <Section title="Upcoming exams" viewAllTo="/competitive-exams">
          {data.upcomingExams.length === 0 ? (
            <p className="text-sm text-slate-400">No exams in the next 14 days.</p>
          ) : (
            <ul className="space-y-2">
              {data.upcomingExams.map((e) => (
                <li key={e.id} className="flex items-center justify-between text-sm">
                  <span className="text-slate-700 flex items-center gap-2">
                    {e.examName} <StatusBadge status={e.status} />
                  </span>
                  <span className="text-slate-400 text-xs">{formatDate(e.examDate)}</span>
                </li>
              ))}
            </ul>
          )}
        </Section>
      </div>
    </div>
  )
}
