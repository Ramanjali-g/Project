import ResourcePage from '../components/common/ResourcePage'
import { companyApi } from '../api/companyApi'

const fields = [
  { name: 'name', label: 'Company name', type: 'text', required: true },
  { name: 'industry', label: 'Industry', type: 'text' },
  { name: 'location', label: 'Location', type: 'text' },
  { name: 'website', label: 'Website', type: 'text', placeholder: 'https://…' },
  { name: 'notes', label: 'Notes', type: 'textarea', colSpan: 2 },
]

export default function Companies() {
  return (
    <ResourcePage
      title="Companies"
      description="Companies you're tracking applications with."
      api={companyApi}
      fields={fields}
      emptyDescription="Add a company so you can link applications to it."
    />
  )
}
