import ResourcePage from '../components/common/ResourcePage'
import { interviewApi } from '../api/interviewApi'
import { INTERVIEW_STATUSES, INTERVIEW_TYPES } from '../utils/constants'

const fields = [
  { name: 'company', label: 'Company', type: 'text', required: true },
  { name: 'role', label: 'Role', type: 'text', required: true },
  { name: 'type', label: 'Interview type', type: 'select', options: INTERVIEW_TYPES },
  { name: 'round', label: 'Round #', type: 'number' },
  { name: 'dateTime', label: 'Date & time', type: 'datetime-local', required: true },
  { name: 'status', label: 'Status', type: 'select', options: INTERVIEW_STATUSES, default: 'SCHEDULED' },
  { name: 'notes', label: 'Notes', type: 'textarea', colSpan: 2 },
]

const columns = [
  { key: 'company', label: 'Company' },
  { key: 'role', label: 'Role' },
  { key: 'type', label: 'Type' },
  { key: 'dateTime', label: 'When' },
  { key: 'status', label: 'Status' },
]

export default function Interviews() {
  return (
    <ResourcePage
      title="Interviews"
      description="Every interview round, past and upcoming."
      api={interviewApi}
      fields={fields}
      columns={columns}
      emptyDescription="Schedule your first interview to see it here and on your calendar."
    />
  )
}
