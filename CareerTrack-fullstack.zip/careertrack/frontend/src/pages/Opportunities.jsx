import { useEffect, useState } from 'react'
import { Plus, Sparkles } from 'lucide-react'
import { opportunityApi } from '../api/opportunityApi'
import Modal from '../components/common/Modal'
import LoadingSpinner from '../components/common/LoadingSpinner'
import EmptyState from '../components/common/EmptyState'
import { OPPORTUNITY_CATEGORIES } from '../utils/constants'
import { formatDate, formatLabel } from '../utils/format'

const emptyForm = {
  title: '', category: 'JOB', organization: '', location: '', role: '',
  eligibility: '', description: '', publishedDate: '', deadline: '',
  sourceName: '', sourceUrl: '', verified: false,
}

function OpportunityCard({ item, explanation }) {
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="font-medium text-slate-800">{item.title}</p>
          <p className="text-sm text-slate-500">{item.organization}{item.location ? ` · ${item.location}` : ''}</p>
        </div>
        <span className="text-[11px] font-medium bg-slate-100 text-slate-600 px-2 py-1 rounded-full whitespace-nowrap">
          {formatLabel(item.category)}
        </span>
      </div>
      {item.description && <p className="text-sm text-slate-600 mt-2 line-clamp-2">{item.description}</p>}
      <div className="flex items-center justify-between mt-3 text-xs text-slate-400">
        <span>{item.sourceName || 'Unverified source'}{item.deadline ? ` · Deadline ${formatDate(item.deadline)}` : ''}</span>
        {item.sourceUrl && (
          <a href={item.sourceUrl} target="_blank" rel="noreferrer" className="text-brand-600 hover:underline">
            View source
          </a>
        )}
      </div>
      {explanation && (
        <p className="text-xs text-brand-700 bg-brand-50 rounded-lg px-2 py-1.5 mt-3 flex items-center gap-1.5">
          <Sparkles size={12} /> {explanation}
        </p>
      )}
    </div>
  )
}

export default function Opportunities() {
  const [tab, setTab] = useState('forMe')
  const [forMe, setForMe] = useState([])
  const [browseResults, setBrowseResults] = useState([])
  const [loading, setLoading] = useState(true)
  const [filters, setFilters] = useState({ category: '', role: '', location: '' })
  const [modalOpen, setModalOpen] = useState(false)
  const [form, setForm] = useState(emptyForm)
  const [saving, setSaving] = useState(false)
  const [formError, setFormError] = useState('')

  useEffect(() => {
    loadForMe()
    loadBrowse({})
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  function loadForMe() {
    opportunityApi.forMe().then(setForMe).catch(() => setForMe([]))
  }

  function loadBrowse(params) {
    setLoading(true)
    opportunityApi
      .list(params)
      .then(setBrowseResults)
      .finally(() => setLoading(false))
  }

  function applyFilters(e) {
    e.preventDefault()
    const params = {}
    if (filters.category) params.category = filters.category
    if (filters.role) params.role = filters.role
    if (filters.location) params.location = filters.location
    loadBrowse(params)
  }

  async function handleCreate(e) {
    e.preventDefault()
    setSaving(true)
    setFormError('')
    try {
      const payload = { ...form, publishedDate: form.publishedDate || null, deadline: form.deadline || null }
      const created = await opportunityApi.create(payload)
      setBrowseResults((prev) => [created, ...prev])
      setModalOpen(false)
      setForm(emptyForm)
      loadForMe()
    } catch (err) {
      setFormError(err.response?.data?.message || 'Could not save this opportunity.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div>
          <h1 className="text-xl font-semibold text-slate-800">Opportunities</h1>
          <p className="text-sm text-slate-500 mt-0.5">Aggregated jobs, internships, government roles and exams.</p>
        </div>
        <button
          onClick={() => setModalOpen(true)}
          className="flex items-center gap-1.5 bg-brand-600 hover:bg-brand-700 text-white text-sm font-medium px-4 py-2 rounded-lg"
        >
          <Plus size={16} /> Add Opportunity
        </button>
      </div>

      <div className="flex gap-2 mb-5">
        {[
          { key: 'forMe', label: 'For You' },
          { key: 'browse', label: 'Browse All' },
        ].map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`text-sm font-medium px-3 py-1.5 rounded-lg ${
              tab === t.key ? 'bg-brand-600 text-white' : 'bg-white border border-slate-200 text-slate-600'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'forMe' && (
        forMe.length === 0 ? (
          <EmptyState
            title="No personalized matches yet"
            description="Add some opportunities, and update your profile skills/preferred roles for better matches."
          />
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {forMe.map((m) => (
              <OpportunityCard key={m.opportunity.id} item={m.opportunity} explanation={m.explanation} />
            ))}
          </div>
        )
      )}

      {tab === 'browse' && (
        <div>
          <form onSubmit={applyFilters} className="flex flex-wrap gap-3 mb-5 bg-white border border-slate-200 rounded-xl p-4">
            <select
              value={filters.category}
              onChange={(e) => setFilters((f) => ({ ...f, category: e.target.value }))}
              className="border border-slate-200 rounded-lg px-3 py-2 text-sm bg-white"
            >
              <option value="">All categories</option>
              {OPPORTUNITY_CATEGORIES.map((c) => (
                <option key={c} value={c}>{formatLabel(c)}</option>
              ))}
            </select>
            <input
              placeholder="Role / title"
              value={filters.role}
              onChange={(e) => setFilters((f) => ({ ...f, role: e.target.value }))}
              className="border border-slate-200 rounded-lg px-3 py-2 text-sm flex-1 min-w-[160px]"
            />
            <input
              placeholder="Location"
              value={filters.location}
              onChange={(e) => setFilters((f) => ({ ...f, location: e.target.value }))}
              className="border border-slate-200 rounded-lg px-3 py-2 text-sm flex-1 min-w-[160px]"
            />
            <button type="submit" className="bg-slate-800 hover:bg-slate-900 text-white text-sm font-medium px-4 py-2 rounded-lg">
              Search
            </button>
          </form>

          {loading ? (
            <LoadingSpinner />
          ) : browseResults.length === 0 ? (
            <EmptyState title="No opportunities found" description="Try a different filter, or add one yourself." />
          ) : (
            <div className="grid md:grid-cols-2 gap-4">
              {browseResults.map((item) => (
                <OpportunityCard key={item.id} item={item} />
              ))}
            </div>
          )}
        </div>
      )}

      {modalOpen && (
        <Modal
          title="Add Opportunity"
          wide
          onClose={() => setModalOpen(false)}
          footer={
            <>
              <button onClick={() => setModalOpen(false)} className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-lg">
                Cancel
              </button>
              <button form="opportunity-form" type="submit" disabled={saving} className="px-4 py-2 text-sm font-medium bg-brand-600 hover:bg-brand-700 text-white rounded-lg disabled:opacity-60">
                {saving ? 'Saving…' : 'Save'}
              </button>
            </>
          }
        >
          <form id="opportunity-form" onSubmit={handleCreate} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {formError && <p className="sm:col-span-2 text-sm text-red-600 bg-red-50 rounded-lg px-3 py-2">{formError}</p>}
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Title</label>
              <input required value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Category</label>
              <select value={form.category} onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))} className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm bg-white">
                {OPPORTUNITY_CATEGORIES.map((c) => <option key={c} value={c}>{formatLabel(c)}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Organization</label>
              <input value={form.organization} onChange={(e) => setForm((f) => ({ ...f, organization: e.target.value }))} className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Location</label>
              <input value={form.location} onChange={(e) => setForm((f) => ({ ...f, location: e.target.value }))} className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Role</label>
              <input value={form.role} onChange={(e) => setForm((f) => ({ ...f, role: e.target.value }))} className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Deadline</label>
              <input type="date" value={form.deadline} onChange={(e) => setForm((f) => ({ ...f, deadline: e.target.value }))} className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm" />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-500 mb-1">Eligibility</label>
              <input value={form.eligibility} onChange={(e) => setForm((f) => ({ ...f, eligibility: e.target.value }))} className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm" />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-500 mb-1">Description</label>
              <textarea rows={3} value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Source name</label>
              <input value={form.sourceName} onChange={(e) => setForm((f) => ({ ...f, sourceName: e.target.value }))} className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm" placeholder="e.g. Official careers page" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Source URL</label>
              <input value={form.sourceUrl} onChange={(e) => setForm((f) => ({ ...f, sourceUrl: e.target.value }))} className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm" placeholder="https://…" />
            </div>
          </form>
        </Modal>
      )}
    </div>
  )
}
