import ResourcePage from '../components/common/ResourcePage'
import { examApi } from '../api/examApi'
import { COMPETITIVE_EXAM_NAMES, OPPORTUNITY_STATUSES } from '../utils/constants'

const fields = [
  { name: 'examName', label: 'Exam', type: 'select', options: COMPETITIVE_EXAM_NAMES, required: true },
  { name: 'registrationDeadline', label: 'Registration deadline', type: 'date' },
  { name: 'admitCardDate', label: 'Admit card date', type: 'date' },
  { name: 'examDate', label: 'Exam date', type: 'date' },
  { name: 'resultDate', label: 'Result date', type: 'date' },
  { name: 'targetScore', label: 'Target score', type: 'number' },
  { name: 'actualScore', label: 'Actual score', type: 'number' },
  { name: 'status', label: 'Status', type: 'select', options: OPPORTUNITY_STATUSES, default: 'UPCOMING' },
  { name: 'notes', label: 'Notes', type: 'textarea', colSpan: 2 },
]

const columns = [
  { key: 'examName', label: 'Exam' },
  { key: 'registrationDeadline', label: 'Reg. deadline' },
  { key: 'examDate', label: 'Exam date' },
  { key: 'targetScore', label: 'Target' },
  { key: 'actualScore', label: 'Actual' },
  { key: 'status', label: 'Status' },
]

export default function CompetitiveExams() {
  return (
    <ResourcePage
      title="Competitive Exams"
      description="GATE, CAT, GRE, GMAT, CUET, JEE, NEET and more."
      api={examApi}
      fields={fields}
      columns={columns}
      emptyDescription="Add an exam you're preparing for."
    />
  )
}
