import { useEffect, useState } from 'react'
import { Bell, LogOut } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { notificationApi } from '../../api/notificationApi'

export default function Navbar() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const [unread, setUnread] = useState(0)

  useEffect(() => {
    let mounted = true
    notificationApi
      .unreadCount()
      .then((d) => mounted && setUnread(d.count))
      .catch(() => {})
    return () => {
      mounted = false
    }
  }, [])

  return (
    <header className="h-16 border-b border-slate-200 bg-white flex items-center justify-between px-4 md:px-6 sticky top-0 z-10">
      <span className="md:hidden text-lg font-bold text-brand-700">CareerTrack</span>
      <div className="flex-1" />
      <div className="flex items-center gap-4">
        <button onClick={() => navigate('/notifications')} className="relative text-slate-500 hover:text-slate-700">
          <Bell size={20} />
          {unread > 0 && (
            <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white text-[10px] leading-none rounded-full h-4 min-w-[16px] px-1 flex items-center justify-center">
              {unread > 9 ? '9+' : unread}
            </span>
          )}
        </button>
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center text-xs font-semibold">
            {user?.name?.slice(0, 1).toUpperCase() || '?'}
          </div>
          <span className="text-sm font-medium text-slate-700 hidden sm:inline">{user?.name}</span>
        </div>
        <button onClick={logout} className="text-slate-400 hover:text-red-600" title="Log out">
          <LogOut size={18} />
        </button>
      </div>
    </header>
  )
}
