import { NavLink } from 'react-router-dom'
import {
  LayoutDashboard, Briefcase, Building2, Users, ClipboardList,
  Landmark, GraduationCap, BookOpen, CalendarDays, Compass, MailSearch, BarChart3, UserRound,
} from 'lucide-react'

const links = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/applications', label: 'Applications', icon: Briefcase },
  { to: '/companies', label: 'Companies', icon: Building2 },
  { to: '/interviews', label: 'Interviews', icon: Users },
  { to: '/assessments', label: 'Assessments', icon: ClipboardList },
  { to: '/government-jobs', label: 'Government Jobs', icon: Landmark },
  { to: '/competitive-exams', label: 'Competitive Exams', icon: GraduationCap },
  { to: '/preparation', label: 'Preparation', icon: BookOpen },
  { to: '/calendar', label: 'Calendar', icon: CalendarDays },
  { to: '/opportunities', label: 'Opportunities', icon: Compass },
  { to: '/email-assistant', label: 'AI Email Assistant', icon: MailSearch },
  { to: '/analytics', label: 'Analytics', icon: BarChart3 },
  { to: '/profile', label: 'Profile', icon: UserRound },
]

export default function Sidebar() {
  return (
    <aside className="hidden md:flex md:flex-col w-64 shrink-0 border-r border-slate-200 bg-white h-screen sticky top-0">
      <div className="px-5 py-5 border-b border-slate-100">
        <span className="text-lg font-bold text-brand-700">CareerTrack</span>
      </div>
      <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">
        {links.map(({ to, label, icon: Icon, end }) => (
          <NavLink
            key={to}
            to={to}
            end={end}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                isActive ? 'bg-brand-50 text-brand-700' : 'text-slate-600 hover:bg-slate-50'
              }`
            }
          >
            <Icon size={17} />
            {label}
          </NavLink>
        ))}
      </nav>
    </aside>
  )
}
