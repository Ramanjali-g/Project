import { useEffect, useMemo, useState } from 'react'
import { Pencil, Plus, Trash2 } from 'lucide-react'
import Modal from './Modal'
import LoadingSpinner from './LoadingSpinner'
import EmptyState from './EmptyState'
import StatusBadge from './StatusBadge'
import { formatLabel } from '../../utils/format'

const STATUS_LIKE_NAMES = new Set(['status', 'type'])

function optionValue(opt) {
  return typeof opt === 'string' ? opt : opt.value
}
function optionLabel(opt) {
  return typeof opt === 'string' ? formatLabel(opt) : opt.label
}

function emptyValuesFromFields(fields) {
  const values = {}
  fields.forEach((f) => {
    values[f.name] = f.default ?? ''
  })
  return values
}

function toFormValue(field, raw) {
  if (raw === null || raw === undefined) return ''
  if (field.type === 'datetime-local' && typeof raw === 'string') {
    return raw.length >= 16 ? raw.slice(0, 16) : raw
  }
  return raw
}

/**
 * A reusable "table + add/edit modal" page for simple CRUD entities.
 * Bespoke pages (Applications, EmailAssistant, etc.) that need custom
 * behaviour compose their own layout instead of using this component.
 */
export default function ResourcePage({
  title,
  description,
  api,
  fields,
  columns,
  emptyTitle = 'No records yet',
  emptyDescription = 'Add your first entry to get started.',
  onBeforeSubmit,
  toolbar,
}) {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [modalOpen, setModalOpen] = useState(false)
  const [editingId, setEditingId] = useState(null)
  const [formValues, setFormValues] = useState(() => emptyValuesFromFields(fields))
  const [saving, setSaving] = useState(false)
  const [formError, setFormError] = useState('')

  const effectiveColumns = useMemo(() => columns || fields.map((f) => ({ key: f.name, label: f.label })), [columns, fields])

  async function load() {
    setLoading(true)
    setError('')
    try {
      const data = await api.list()
      setItems(data)
    } catch (e) {
      setError(e.response?.data?.message || 'Failed to load data.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  function openCreate() {
    setEditingId(null)
    setFormValues(emptyValuesFromFields(fields))
    setFormError('')
    setModalOpen(true)
  }

  function openEdit(row) {
    setEditingId(row.id)
    const values = {}
    fields.forEach((f) => {
      values[f.name] = toFormValue(f, row[f.name])
    })
    setFormValues(values)
    setFormError('')
    setModalOpen(true)
  }

  async function handleDelete(row) {
    if (!window.confirm('Delete this record? This cannot be undone.')) return
    try {
      await api.remove(row.id)
      setItems((prev) => prev.filter((i) => i.id !== row.id))
    } catch (e) {
      alert(e.response?.data?.message || 'Failed to delete.')
    }
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setSaving(true)
    setFormError('')
    try {
      let payload = { ...formValues }
      fields.forEach((f) => {
        if (f.type === 'number' && payload[f.name] !== '') {
          payload[f.name] = Number(payload[f.name])
        }
        if (payload[f.name] === '') {
          payload[f.name] = null
        }
      })
      if (onBeforeSubmit) payload = onBeforeSubmit(payload, formValues)

      if (editingId) {
        const updated = await api.update(editingId, payload)
        setItems((prev) => prev.map((i) => (i.id === editingId ? updated : i)))
      } else {
        const created = await api.create(payload)
        setItems((prev) => [created, ...prev])
      }
      setModalOpen(false)
    } catch (e) {
      setFormError(e.response?.data?.message || 'Something went wrong. Please check the form and try again.')
    } finally {
      setSaving(false)
    }
  }

  function renderCell(row, col) {
    if (col.render) return col.render(row)
    const value = row[col.key]
    const field = fields.find((f) => f.name === col.key)
    if (field?.type === 'select' && STATUS_LIKE_NAMES.has(field.name)) {
      return <StatusBadge status={value} />
    }
    if (field?.type === 'date' && value) return new Date(value).toLocaleDateString()
    if (field?.type === 'datetime-local' && value) return new Date(value).toLocaleString()
    if (value === null || value === undefined || value === '') return <span className="text-slate-300">—</span>
    return String(value)
  }

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div>
          <h1 className="text-xl font-semibold text-slate-800">{title}</h1>
          {description && <p className="text-sm text-slate-500 mt-0.5">{description}</p>}
        </div>
        <div className="flex items-center gap-2">
          {toolbar}
          <button
            onClick={openCreate}
            className="flex items-center gap-1.5 bg-brand-600 hover:bg-brand-700 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors"
          >
            <Plus size={16} /> Add New
          </button>
        </div>
      </div>

      {loading && <LoadingSpinner />}
      {!loading && error && <p className="text-red-600 text-sm">{error}</p>}

      {!loading && !error && items.length === 0 && (
        <EmptyState title={emptyTitle} description={emptyDescription} />
      )}

      {!loading && !error && items.length > 0 && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
                <tr>
                  {effectiveColumns.map((col) => (
                    <th key={col.key} className="text-left font-medium px-4 py-3 whitespace-nowrap">
                      {col.label}
                    </th>
                  ))}
                  <th className="px-4 py-3" />
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {items.map((row) => (
                  <tr key={row.id} className="hover:bg-slate-50/60">
                    {effectiveColumns.map((col) => (
                      <td key={col.key} className="px-4 py-3 whitespace-nowrap">
                        {renderCell(row, col)}
                      </td>
                    ))}
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <button onClick={() => openEdit(row)} className="text-slate-400 hover:text-brand-600 p-1.5">
                        <Pencil size={16} />
                      </button>
                      <button onClick={() => handleDelete(row)} className="text-slate-400 hover:text-red-600 p-1.5">
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {modalOpen && (
        <Modal
          title={editingId ? `Edit ${title.replace(/s$/, '')}` : `Add ${title.replace(/s$/, '')}`}
          onClose={() => setModalOpen(false)}
          wide
          footer={
            <>
              <button
                onClick={() => setModalOpen(false)}
                className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                form="resource-form"
                type="submit"
                disabled={saving}
                className="px-4 py-2 text-sm font-medium bg-brand-600 hover:bg-brand-700 text-white rounded-lg disabled:opacity-60"
              >
                {saving ? 'Saving…' : 'Save'}
              </button>
            </>
          }
        >
          <form id="resource-form" onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {formError && (
              <p className="sm:col-span-2 text-sm text-red-600 bg-red-50 rounded-lg px-3 py-2">{formError}</p>
            )}
            {fields.map((f) => (
              <div key={f.name} className={f.colSpan === 2 ? 'sm:col-span-2' : ''}>
                <label className="block text-xs font-medium text-slate-500 mb-1">{f.label}</label>
                {f.type === 'textarea' ? (
                  <textarea
                    className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-300"
                    rows={3}
                    value={formValues[f.name] ?? ''}
                    onChange={(e) => setFormValues((v) => ({ ...v, [f.name]: e.target.value }))}
                    required={f.required}
                  />
                ) : f.type === 'select' ? (
                  <select
                    className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-300 bg-white"
                    value={formValues[f.name] ?? ''}
                    onChange={(e) => setFormValues((v) => ({ ...v, [f.name]: e.target.value }))}
                    required={f.required}
                  >
                    <option value="">Select…</option>
                    {f.options.map((opt) => (
                      <option key={optionValue(opt)} value={optionValue(opt)}>
                        {optionLabel(opt)}
                      </option>
                    ))}
                  </select>
                ) : (
                  <input
                    type={f.type || 'text'}
                    step={f.type === 'number' ? 'any' : undefined}
                    className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-300"
                    value={formValues[f.name] ?? ''}
                    placeholder={f.placeholder}
                    onChange={(e) => setFormValues((v) => ({ ...v, [f.name]: e.target.value }))}
                    required={f.required}
                  />
                )}
              </div>
            ))}
          </form>
        </Modal>
      )}
    </div>
  )
}
