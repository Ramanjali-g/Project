export default function EmptyState({ title = 'Nothing here yet', description, action }) {
  return (
    <div className="text-center py-16 px-4 border-2 border-dashed border-slate-200 rounded-xl">
      <p className="text-slate-600 font-medium">{title}</p>
      {description && <p className="text-slate-400 text-sm mt-1">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  )
}
