import { STATUS_COLORS } from '../../utils/constants'
import { formatLabel } from '../../utils/format'

export default function StatusBadge({ status }) {
  if (!status) return <span className="text-slate-400 text-sm">—</span>
  const classes = STATUS_COLORS[status] || 'bg-slate-100 text-slate-700'
  return (
    <span className={`inline-block px-2.5 py-1 rounded-full text-xs font-medium ${classes}`}>
      {formatLabel(status)}
    </span>
  )
}
