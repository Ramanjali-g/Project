import { Routes, Route } from 'react-router-dom'
import ProtectedRoute from './components/common/ProtectedRoute'
import Layout from './components/layout/Layout'

import Login from './pages/Login'
import Register from './pages/Register'
import Dashboard from './pages/Dashboard'
import Applications from './pages/Applications'
import Companies from './pages/Companies'
import Interviews from './pages/Interviews'
import Assessments from './pages/Assessments'
import GovernmentJobs from './pages/GovernmentJobs'
import CompetitiveExams from './pages/CompetitiveExams'
import Preparation from './pages/Preparation'
import CalendarView from './pages/CalendarView'
import Opportunities from './pages/Opportunities'
import EmailAssistant from './pages/EmailAssistant'
import Notifications from './pages/Notifications'
import Analytics from './pages/Analytics'
import Profile from './pages/Profile'

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />

      <Route
        path="/"
        element={
          <ProtectedRoute>
            <Layout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Dashboard />} />
        <Route path="applications" element={<Applications />} />
        <Route path="companies" element={<Companies />} />
        <Route path="interviews" element={<Interviews />} />
        <Route path="assessments" element={<Assessments />} />
        <Route path="government-jobs" element={<GovernmentJobs />} />
        <Route path="competitive-exams" element={<CompetitiveExams />} />
        <Route path="preparation" element={<Preparation />} />
        <Route path="calendar" element={<CalendarView />} />
        <Route path="opportunities" element={<Opportunities />} />
        <Route path="email-assistant" element={<EmailAssistant />} />
        <Route path="notifications" element={<Notifications />} />
        <Route path="analytics" element={<Analytics />} />
        <Route path="profile" element={<Profile />} />
      </Route>
    </Routes>
  )
}
